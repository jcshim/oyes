// usbd_mtp_if.c - Minimal MTP app interface for STM32 + FatFs
#include "usbd_def.h"
#include "usbd_core.h"
#include "fatfs.h"
extern FATFS SDFatFS;
extern char SDPath[4];
          /* FatFs */
#include <string.h>
#include <stdint.h>

/* Response codes */
#define PTP_RC_OK               0x2001
#define PTP_RC_GeneralError     0x2002

/* Exposed by usbd_mtp.c */
void MTP_SendEvent(uint16_t evtCode, uint32_t param1);

/* Helpers: write little-endian */
static inline void wr16(uint8_t *p, uint16_t v){ p[0]=v&0xFF; p[1]=(v>>8)&0xFF; }
static inline void wr32(uint8_t *p, uint32_t v){ p[0]=v&0xFF; p[1]=(v>>8)&0xFF; p[2]=(v>>16)&0xFF; p[3]=(v>>24)&0xFF; }

/* PTP Unicode string: 1 byte length in characters (including NUL), then UTF-16LE */
static uint32_t wr_ptp_string(uint8_t *buf, const char *ascii)
{
  if (!ascii || !*ascii){ buf[0]=0; return 1; }
  uint8_t *p = buf;
  size_t n = strlen(ascii);
  *p++ = (uint8_t)(n+1);
  for (size_t i=0;i<n;i++){ *p++ = (uint8_t)ascii[i]; *p++ = 0; }
  *p++ = 0; *p++ = 0;
  return (uint32_t)(p - buf);
}

/* ========== Public interface expected by class ========== */
typedef struct
{
  uint32_t (*GetDeviceInfo)(uint8_t *buf, uint32_t max);
  uint32_t (*OpenSession)(uint32_t sessionId);
  uint32_t (*CloseSession)(void);
  uint32_t (*GetStorageIDs)(uint8_t *buf, uint32_t max, uint32_t *xfer_len);
  uint32_t (*GetStorageInfo)(uint32_t storageId, uint8_t *buf, uint32_t max, uint32_t *xfer_len);
} USBD_MTP_ItfTypeDef;

extern USBD_MTP_ItfTypeDef USBD_MTP_fops; /* exported below */

/* Private state */
static uint8_t mounted = 0;
static uint32_t g_storage_id = 0x00010001;

/* Build DeviceInfo dataset (subset sufficient for Windows) */
static uint32_t MTP_GetDeviceInfo(uint8_t *buf, uint32_t max)
{
  uint8_t *p = buf;
  if (max < 256) return 0;

  /* Standard version, VendorExtensionID 0, version, vendor ext desc */
  wr16(p, 0x0100); p+=2;            /* StandardVersion 1.00 */
  wr32(p, 0); p+=4;                 /* VendorExtensionID none */
  wr16(p, 0x006a); p+=2;            /* MTP version (arbitrary nonzero) */
  p += wr_ptp_string(p, "");        /* VendorExtensionDesc (empty) */

  /* FunctionalMode */
  wr16(p, 0); p+=2;

  /* Supported operations (array of uint16) - include the ones we implement */
  uint16_t ops[] = { 0x1001, 0x1002, 0x1004, 0x1005 };
  wr32(p, sizeof(ops)/2); p+=4;
  for (size_t i=0;i<sizeof(ops)/2;i++){ wr16(p, ops[i]); p+=2; }

  /* Events (we can send StorageAdded) */
  uint16_t evs[] = { 0x4001 /*StorageAdded*/ };
  wr32(p, sizeof(evs)/2); p+=4;
  for (size_t i=0;i<sizeof(evs)/2;i++){ wr16(p, evs[i]); p+=2; }

  /* Device Properties (none) */
  wr32(p, 0); p+=4;

  /* Capture / Playback formats (none) */
  wr32(p, 0); p+=4;
  wr32(p, 0); p+=4;

  /* Manufacturer, Model, DeviceVersion, SerialNumber */
  p += wr_ptp_string(p, "STMicroelectronics");
  p += wr_ptp_string(p, "STM32H7B0 MTP");
  p += wr_ptp_string(p, "1.0");
  p += wr_ptp_string(p, "0001");

  return (uint32_t)(p - buf);
}

static uint32_t MTP_OpenSession(uint32_t sessionId)
{
  if (sessionId == 0) return PTP_RC_GeneralError;
  if (!mounted){

    FRESULT fr = f_mount(&SDFatFS, (TCHAR const*)SDPath, 1);
    if (fr != FR_OK){
      /* still allow session open; Windows can open empty storage */
    } else {
      mounted = 1;
    }
  }
  /* Send StorageAdded to nudge Windows */
  MTP_SendEvent(0x4001, g_storage_id);
  return PTP_RC_OK;
}

static uint32_t MTP_CloseSession(void)
{
  if (mounted){
    f_mount(0, (TCHAR const*)SDPath, 0);
    mounted = 0;
  }
  return PTP_RC_OK;
}

static uint32_t MTP_GetStorageIDs(uint8_t *buf, uint32_t max, uint32_t *xfer_len)
{
  if (max < 8) return PTP_RC_GeneralError;
  wr32(buf, 1);              /* number of storage IDs */
  wr32(buf+4, g_storage_id); /* the storage ID */
  *xfer_len = 8;
  return PTP_RC_OK;
}

static uint32_t MTP_GetStorageInfo(uint32_t storageId, uint8_t *buf, uint32_t max, uint32_t *xfer_len)
{
  if (storageId != g_storage_id) return PTP_RC_GeneralError;
  if (max < 256) return PTP_RC_GeneralError;

  /* Defaults */
  uint64_t total = 8ULL*1024*1024; /* 8MB default if not mounted */
  uint64_t freeb = 7ULL*1024*1024;

  if (mounted){
    FATFS *fs = &SDFatFS;
    DWORD fre_clust;
    if (f_getfree((TCHAR const*)SDPath, &fre_clust, &fs) == FR_OK && SDFatFS.csize){
      uint64_t sect_size = 512; /* typical */
      uint64_t tot_sect = (uint64_t)SDFatFS.n_fatent * SDFatFS.csize;
      uint64_t fre_sect = (uint64_t)fre_clust * SDFatFS.csize;
      total = tot_sect * sect_size;
      freeb = fre_sect * sect_size;
    }
  }

  uint8_t *p = buf;
  wr16(p, 0x0003); p+=2; /* StorageType = Removable RAM */
  wr16(p, 0x0002); p+=2; /* FilesystemType = GenericHierarchical */
  wr16(p, 0x0000); p+=2; /* AccessCapability = Read-Write */
    /* write 64-bit little endian */
  uint64_t vals[2] = { total, freeb };
  for (int i=0;i<2;i++){
    uint64_t v = vals[i];
    for (int b=0;b<8;b++){ *p++ = (uint8_t)(v & 0xFF); v >>= 8; }
  }
  p += wr_ptp_string(p, "SD-Card");
  p += wr_ptp_string(p, "MTP_SD");

  *xfer_len = (uint32_t)(p - buf);
  return PTP_RC_OK;
}

/* Export table */
USBD_MTP_ItfTypeDef USBD_MTP_fops =
{
  MTP_GetDeviceInfo,
  MTP_OpenSession,
  MTP_CloseSession,
  MTP_GetStorageIDs,
  MTP_GetStorageInfo
};
