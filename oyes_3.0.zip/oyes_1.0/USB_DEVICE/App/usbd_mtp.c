// usbd_mtp.c - Minimal MTP (PTP) USB class for STM32 (FS) - Working minimal to make Windows Explorer show device
#include "usbd_def.h"
#include "usbd_ctlreq.h"
#include "usbd_core.h"
#include <string.h>
#include <stdint.h>

/* ---------- Config ---------- */
#ifndef MTP_IN_EP
#define MTP_IN_EP     0x81  /* Bulk IN  */
#endif
#ifndef MTP_OUT_EP
#define MTP_OUT_EP    0x01  /* Bulk OUT */
#endif
#ifndef MTP_EVT_EP
#define MTP_EVT_EP    0x83  /* Interrupt IN (events) */
#endif

#define MTP_EP_MPS_FS 64
#define MTP_TX_BUF_SZ 1024
#define MTP_RX_BUF_SZ 512

/* ---------- PTP/MTP basics ---------- */
#define PTP_CNT_TYPE_COMMAND  0x0001
#define PTP_CNT_TYPE_DATA     0x0002
#define PTP_CNT_TYPE_RESPONSE 0x0003
#define PTP_CNT_TYPE_EVENT    0x0004

/* PTP operation codes (subset) */
#define PTP_OC_GetDeviceInfo    0x1001
#define PTP_OC_OpenSession      0x1002
#define PTP_OC_GetStorageIDs    0x1004
#define PTP_OC_GetStorageInfo   0x1005

/* PTP response codes */
#define PTP_RC_OK               0x2001
#define PTP_RC_GeneralError     0x2002
#define PTP_RC_SessionNotOpen   0x2003

/* Interface (app) callbacks implemented in usbd_mtp_if.c */
typedef struct
{
  /* Return length of dataset written to buf; 0 on error */
  uint32_t (*GetDeviceInfo)(uint8_t *buf, uint32_t max);
  /* Return PTP_RC_xxxx */
  uint32_t (*OpenSession)(uint32_t sessionId);
  uint32_t (*CloseSession)(void);
  uint32_t (*GetStorageIDs)(uint8_t *buf, uint32_t max, uint32_t *xfer_len);
  uint32_t (*GetStorageInfo)(uint32_t storageId, uint8_t *buf, uint32_t max, uint32_t *xfer_len);
} USBD_MTP_ItfTypeDef;

extern USBD_MTP_ItfTypeDef USBD_MTP_fops;

/* ---------- Class private ---------- */
typedef enum { MTP_IDLE=0, MTP_RX_CMD, MTP_TX_DATA, MTP_TX_RESP } mtp_state_t;

typedef struct {
  USBD_HandleTypeDef *pdev;
  mtp_state_t state;
  uint8_t tx[MTP_TX_BUF_SZ];
  uint8_t rx[MTP_RX_BUF_SZ];
  uint32_t rx_len;

  uint32_t curTxId;
  uint32_t curOpCode;
  uint32_t sessionId;
} MTP_ClassCtx;

static MTP_ClassCtx g_mtp;
static USBD_MTP_ItfTypeDef *g_mtp_itf = NULL;

/* helpers */
static inline void put16(uint8_t *p, uint16_t v){ p[0]=v&0xFF; p[1]=(v>>8)&0xFF; }
static inline void put32(uint8_t *p, uint32_t v){ p[0]=v&0xFF; p[1]=(v>>8)&0xFF; p[2]=(v>>16)&0xFF; p[3]=(v>>24)&0xFF; }
static inline uint16_t rd16(const uint8_t *p){ return (uint16_t)p[0] | ((uint16_t)p[1]<<8); }
static inline uint32_t rd32(const uint8_t *p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
static inline USBD_MTP_ItfTypeDef* mtp_itf(void){
  if (g_mtp_itf) return g_mtp_itf;
  return &USBD_MTP_fops;
}


/* ---------- Descriptors (single interface, 3 endpoints) ---------- */
__ALIGN_BEGIN static uint8_t USBD_MTP_CfgDesc[] __ALIGN_END =
{
  /* Configuration Descriptor */
  0x09, USB_DESC_TYPE_CONFIGURATION,
  0x27, 0x00, /* wTotalLength = 39 */
  0x01, /* bNumInterfaces */
  0x01, /* bConfigurationValue */
  0x00, /* iConfiguration */
  0x80, /* bmAttributes: bus powered */
  0x32, /* MaxPower 100mA */

  /* Interface Descriptor: Still Image (PTP/MTP) */
  0x09, USB_DESC_TYPE_INTERFACE,
  0x00, /* bInterfaceNumber */
  0x00, /* bAlternateSetting */
  0x03, /* bNumEndpoints: 3 */
  0x06, /* bInterfaceClass: Still Image */
  0x01, /* bInterfaceSubClass: Still Image */
  0x01, /* bInterfaceProtocol: PIMA 15470 (PTP) */
  0x00, /* iInterface */

  /* Endpoint BULK IN */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_IN_EP, /* bEndpointAddress */
  0x02, /* bmAttributes: BULK */
  MTP_EP_MPS_FS, 0x00, /* wMaxPacketSize */
  0x00, /* bInterval */

  /* Endpoint BULK OUT */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_OUT_EP,
  0x02, /* BULK */
  MTP_EP_MPS_FS, 0x00,
  0x00,

  /* Endpoint INTERRUPT IN (events) */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_EVT_EP,
  0x03, /* INTERRUPT */
  0x10, 0x00, /* 16 bytes */
  0x10  /* 16ms */
};

__ALIGN_BEGIN static uint8_t USBD_MTP_DeviceQualifierDesc[USB_LEN_DEV_QUALIFIER_DESC] __ALIGN_END =
{
  USB_LEN_DEV_QUALIFIER_DESC, USB_DESC_TYPE_DEVICE_QUALIFIER,
  0x00, 0x02,
  0x00, 0x00, 0x00,
  0x40,
  0x01, 0x00,
};

/* forward decls of class callbacks */
static uint8_t  USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t  USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t  USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length);
static uint8_t* USBD_MTP_GetDeviceQualifierDesc(uint16_t *length);

/* Exported class struct */
USBD_ClassTypeDef USBD_MTP =
{
  USBD_MTP_Init,
  USBD_MTP_DeInit,
  USBD_MTP_Setup,
  NULL, /* EP0_TxSent */
  NULL, /* EP0_RxReady */
  USBD_MTP_DataIn,
  USBD_MTP_DataOut,
  NULL, NULL, NULL,
  USBD_MTP_GetCfgDesc,
  USBD_MTP_GetCfgDesc,
  USBD_MTP_GetCfgDesc,
  USBD_MTP_GetDeviceQualifierDesc,
};

/* ---------- Minimal event sender (Interrupt IN) ---------- */
void MTP_SendEvent(uint16_t evtCode, uint32_t param1)
{
  uint8_t evt[16];
  put32(&evt[0], 12+4); /* length */
  put16(&evt[4], PTP_CNT_TYPE_EVENT);
  put16(&evt[6], evtCode);
  put32(&evt[8], 0);   /* TransactionID (none) */
  put32(&evt[12], param1);
  USBD_LL_Transmit(g_mtp.pdev, MTP_EVT_EP, evt, sizeof(evt));
}

/* ---------- Internal helpers ---------- */
static void send_response(uint16_t rc, uint32_t txId)
{
  uint8_t *b = g_mtp.tx;
  put32(&b[0], 12);
  put16(&b[4], PTP_CNT_TYPE_RESPONSE);
  put16(&b[6], rc);
  put32(&b[8], txId);
  USBD_LL_Transmit(g_mtp.pdev, MTP_IN_EP, b, 12);
  g_mtp.state = MTP_IDLE;
}

static void send_data_then_ok(uint16_t opCode, const uint8_t *payload, uint32_t plen, uint32_t txId)
{
  /* send DATA */
  uint8_t *b = g_mtp.tx;
  uint32_t len = 12 + plen;
  put32(&b[0], len);
  put16(&b[4], PTP_CNT_TYPE_DATA);
  put16(&b[6], opCode);
  put32(&b[8], txId);
  if (plen > 0 && payload) memcpy(&b[12], payload, (plen <= (MTP_TX_BUF_SZ-12)) ? plen : (MTP_TX_BUF_SZ-12));
  USBD_LL_Transmit(g_mtp.pdev, MTP_IN_EP, b, (uint16_t)((len <= MTP_TX_BUF_SZ) ? len : (MTP_TX_BUF_SZ)));

  /* then RESPONSE OK */
  g_mtp.state = MTP_TX_RESP;
  /* simple devices use short datasets; after DataIn completes we push Response */
}

/* ---------- Class callbacks ---------- */
static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  g_mtp.pdev = pdev;
  g_mtp.state = MTP_IDLE;
  g_mtp.curTxId = 0;
  g_mtp.curOpCode = 0;
  g_mtp.sessionId = 0;

  USBD_LL_OpenEP(pdev, MTP_IN_EP,  USBD_EP_TYPE_BULK, MTP_EP_MPS_FS);
  USBD_LL_OpenEP(pdev, MTP_OUT_EP, USBD_EP_TYPE_BULK, MTP_EP_MPS_FS);
  USBD_LL_OpenEP(pdev, MTP_EVT_EP, USBD_EP_TYPE_INTR, 16);

  USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, g_mtp.rx, MTP_RX_BUF_SZ);
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  USBD_LL_CloseEP(pdev, MTP_IN_EP);
  USBD_LL_CloseEP(pdev, MTP_OUT_EP);
  USBD_LL_CloseEP(pdev, MTP_EVT_EP);
  g_mtp.state = MTP_IDLE;
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
  /* No class-specific control requests required for simple MTP */
  switch(req->bmRequest & USB_REQ_TYPE_MASK){
  case USB_REQ_TYPE_CLASS:
  default:
    USBD_CtlError (pdev, req);
    return (uint8_t)USBD_FAIL;
  }
}

static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
  if (epnum != (MTP_OUT_EP & 0x7F)) return (uint8_t)USBD_OK;
  g_mtp.rx_len = USBD_LL_GetRxDataSize(pdev, MTP_OUT_EP);

  /* Parse minimal PTP command container (expected in single packet for basic ops) */
  if (g_mtp.rx_len < 12) { USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, g_mtp.rx, MTP_RX_BUF_SZ); return (uint8_t)USBD_OK; }

  uint8_t *b = g_mtp.rx;
  uint32_t len   = rd32(&b[0]);
  uint16_t type  = rd16(&b[4]);
  uint16_t op    = rd16(&b[6]);
  uint32_t txId  = rd32(&b[8]);
  uint32_t p1    = (g_mtp.rx_len >= 16) ? rd32(&b[12]) : 0;
  (void)len;

  g_mtp.curOpCode = op;
  g_mtp.curTxId = txId;

  if (type != PTP_CNT_TYPE_COMMAND){
    send_response(PTP_RC_GeneralError, txId);
    USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, g_mtp.rx, MTP_RX_BUF_SZ);
    return (uint8_t)USBD_OK;
  }

  /* Dispatch minimal commands */
  if (op == PTP_OC_GetDeviceInfo){
    uint32_t w = 0;
    uint8_t payload[MTP_TX_BUF_SZ-12];
    w = mtp_itf()->GetDeviceInfo(payload, sizeof(payload));
    if (w > 0){
      send_data_then_ok(op, payload, w, txId);
    } else {
      send_response(PTP_RC_GeneralError, txId);
    }
  } else if (op == PTP_OC_OpenSession){
    uint32_t rc = mtp_itf()->OpenSession(p1);
    if (rc == PTP_RC_OK) g_mtp.sessionId = p1;
    send_response((uint16_t)rc, txId);
  } else if (op == PTP_OC_GetStorageIDs){
    uint8_t payload[32]; uint32_t w=0;
    uint32_t rc = mtp_itf()->GetStorageIDs(payload, sizeof(payload), &w);
    if (rc == PTP_RC_OK) send_data_then_ok(op, payload, w, txId);
    else send_response((uint16_t)rc, txId);
  } else if (op == PTP_OC_GetStorageInfo){
    uint8_t payload[256]; uint32_t w=0;
    uint32_t rc = mtp_itf()->GetStorageInfo(p1, payload, sizeof(payload), &w);
    if (rc == PTP_RC_OK) send_data_then_ok(op, payload, w, txId);
    else send_response((uint16_t)rc, txId);
  } else {
    /* Not supported in this minimal build */
    send_response(PTP_RC_GeneralError, txId);
  }

  /* re-arm OUT */
  USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, g_mtp.rx, MTP_RX_BUF_SZ);
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
  /* After sending DATA, send the OK response */
  if (g_mtp.state == MTP_TX_RESP){
    send_response(PTP_RC_OK, g_mtp.curTxId);
  }
  return (uint8_t)USBD_OK;
}

static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length)
{
  *length = sizeof(USBD_MTP_CfgDesc);
  return USBD_MTP_CfgDesc;
}

static uint8_t* USBD_MTP_GetDeviceQualifierDesc(uint16_t *length)
{
  *length = sizeof(USBD_MTP_DeviceQualifierDesc);
  return USBD_MTP_DeviceQualifierDesc;
}


/* Public: Register app interface (optional; stored in pdev->pUserData) */
uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops)
{
  (void)pdev;
  if (fops == NULL) return (uint8_t)USBD_FAIL;
  g_mtp_itf = fops;
  return (uint8_t)USBD_OK;
}
