#include "usbd_mtp_if.h"
#include "ff.h"
#include <string.h>
#include <stdio.h>

static MTP_ObjectDB mtp_db;

/* 문자열 끝 비교 함수 */
int ends_with(const char *str, const char *suffix)
{
    if (!str || !suffix) return 0;
    size_t len_str = strlen(str);
    size_t len_suffix = strlen(suffix);
    if (len_suffix > len_str) return 0;
    return (strcasecmp(str + len_str - len_suffix, suffix) == 0);
}

/* Scan root directory and fill mtp_db */
void MTP_ScanObjects(void)
{
    DIR dir;
    FILINFO fno;
    uint32_t handle = 1;

    mtp_db.count = 0;
    if (f_opendir(&dir, "/") != FR_OK) return;

    while (mtp_db.count < MAX_MTP_OBJECTS && f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
        if (fno.fattrib & AM_DIR) continue; // Skip directories
        snprintf(mtp_db.objects[mtp_db.count].filepath, MAX_FILENAME_LEN, "/%s", fno.fname);
        memcpy(&mtp_db.objects[mtp_db.count].finfo, &fno, sizeof(FILINFO));
        mtp_db.objects[mtp_db.count].handle = handle++;
        mtp_db.count++;
    }

    f_closedir(&dir);
}

MTP_Object* MTP_FindObjectByHandle(uint32_t handle)
{
    for (uint32_t i = 0; i < mtp_db.count; i++) {
        if (mtp_db.objects[i].handle == handle)
            return &mtp_db.objects[i];
    }
    return NULL;
}

/* MTP Core Handlers */
static uint32_t MTP_GetDeviceInfo(uint8_t *buf, uint16_t *len)
{
    uint8_t *p = buf;

    *(uint16_t*)p = 0x0100; p += 2;
    *(uint32_t*)p = 0x00000006; p += 4;
    *(uint16_t*)p = 0x0100; p += 2;
    *(uint16_t*)p = 0x0000; p += 2;

    *p++ = 3;
    *(uint16_t*)p = 0x1001; p += 2;
    *(uint16_t*)p = 0x1002; p += 2;
    *(uint16_t*)p = 0x1003; p += 2;

    *p++ = 0; // Events
    *p++ = 0; // Device Properties
    *p++ = 0; // Capture Formats
    *p++ = 3;
    *(uint16_t*)p = 0x3004; p += 2;
    *(uint16_t*)p = 0x3801; p += 2;
    *(uint16_t*)p = 0x3009; p += 2;

    // Manufacturer
    const char *m = "Andong";
    uint8_t *len_m = p++;
    uint8_t count_m = 0;
    while (*m) { *p++ = *m++; *p++ = 0x00; count_m++; }
    *len_m = count_m;

    // Model
    const char *mo = "STM32";
    uint8_t *len_mo = p++;
    uint8_t count_mo = 0;
    while (*mo) { *p++ = *mo++; *p++ = 0x00; count_mo++; }
    *len_mo = count_mo;

    // Version
    const char *ver = "1.0";
    uint8_t *len_ver = p++;
    uint8_t count_ver = 0;
    while (*ver) { *p++ = *ver++; *p++ = 0x00; count_ver++; }
    *len_ver = count_ver;

    // Serial
    const char *s = "MTP1";
    uint8_t *len_s = p++;
    uint8_t count_s = 0;
    while (*s) { *p++ = *s++; *p++ = 0x00; count_s++; }
    *len_s = count_s;

    *len = p - buf;
    return USBD_OK;
}

static uint32_t MTP_OpenSession(uint32_t session_id)
{
    (void)session_id;
    MTP_ScanObjects();

    // 📌 dummy 파일 추가: hello.txt (없을 때만)
    if (mtp_db.count == 0) {
        snprintf(mtp_db.objects[0].filepath, MAX_FILENAME_LEN, "/hello.txt");
        strcpy(mtp_db.objects[0].finfo.fname, "hello.txt");
        mtp_db.objects[0].finfo.fsize = 20;
        mtp_db.objects[0].handle = 1;
        mtp_db.count = 1;
    }

    return USBD_OK;
}

static uint32_t MTP_CloseSession(void) { return USBD_OK; }

static uint32_t MTP_GetStorageIDs(uint8_t *buf, uint16_t *len)
{
    buf[0] = 1; buf[1] = 0;
    buf[2] = 0x01; buf[3] = 0x00; buf[4] = 0x00; buf[5] = 0x00;
    *len = 6;
    return USBD_OK;
}

static uint32_t MTP_GetStorageInfo(uint32_t storage_id, uint8_t *buf, uint16_t *len)
{
    uint8_t *p = buf;
    *(uint16_t*)p = 0x0002; p += 2;
    *(uint16_t*)p = 0x0002; p += 2;
    *(uint16_t*)p = 0x0001; p += 2;

    *(uint64_t*)p = 128 * 1024 * 1024; p += 8;
    *(uint64_t*)p = 64 * 1024 * 1024;  p += 8;
    *(uint32_t*)p = 512; p += 4;

    *p++ = 7; const char *desc = "SDCard";
    while (*desc) { *p++ = *desc++; *p++ = 0x00; }

    *p++ = 3; *p++ = 'M'; *p++ = 0x00; *p++ = 'T'; *p++ = 0x00; *p++ = 'P'; *p++ = 0x00;

    *len = p - buf;
    return USBD_OK;
}

static uint32_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t format_code, uint32_t association, uint8_t *buf, uint16_t *len)
{
    (void)storage_id; (void)format_code; (void)association;
    uint32_t *p = (uint32_t*)buf;
    p[0] = mtp_db.count;
    for (uint32_t i = 0; i < mtp_db.count; i++) p[i + 1] = mtp_db.objects[i].handle;
    *len = (mtp_db.count + 1) * 4;
    return USBD_OK;
}

static uint32_t MTP_GetObjectInfo(uint32_t handle, uint8_t *buf, uint16_t *len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    uint8_t *p = buf;
    *(uint32_t*)p = obj->handle; p += 4;

    const char *ext = strrchr(obj->finfo.fname, '.');
    uint16_t format_code = 0x3000;
    if (ext) {
        if (ends_with(ext, ".txt") || ends_with(ext, ".TXT")) format_code = 0x3004;
        else if (ends_with(ext, ".jpg") || ends_with(ext, ".JPG")) format_code = 0x3801;
        else if (ends_with(ext, ".mp3") || ends_with(ext, ".MP3")) format_code = 0x3009;
        else if (ends_with(ext, ".wav") || ends_with(ext, ".WAV")) format_code = 0x3008;
    }
    *(uint16_t*)p = format_code; p += 2;
    *(uint16_t*)p = 0; p += 2;
    *(uint32_t*)p = obj->finfo.fsize; p += 4;

    memset(p, 0, 20); p += 20;
    *(uint32_t*)p = 0; p += 4;
    *(uint32_t*)p = 0x00010001; p += 4;

    char *name = obj->finfo.fname;
    if (!name || name[0] == '\0') name = "unknown.txt";
    uint8_t *len_pos = p++;
    uint8_t char_count = 0;
    while (*name && char_count < 255) {
        *p++ = *name++; *p++ = 0x00;
        char_count++;
    }
    *len_pos = char_count;

    *len = p - buf;
    return USBD_OK;
}

static uint32_t MTP_GetObject(uint32_t handle, uint8_t *buf, uint32_t offset, uint32_t maxlen, uint32_t *xfer_len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    FIL file;
    if (f_open(&file, obj->filepath, FA_READ) != FR_OK) return USBD_FAIL;
    if (f_lseek(&file, offset) != FR_OK) { f_close(&file); return USBD_FAIL; }

    UINT br = 0;
    FRESULT res = f_read(&file, buf, maxlen, &br);
    f_close(&file);
    if (res != FR_OK) return USBD_FAIL;

    *xfer_len = br;
    return USBD_OK;
}

USBD_MTP_ItfTypeDef USBD_MTP_fops = {
    MTP_GetDeviceInfo,
    MTP_OpenSession,
    MTP_CloseSession,
    MTP_GetStorageIDs,
    MTP_GetStorageInfo,
    MTP_GetObjectHandles,
    MTP_GetObjectInfo,
    MTP_GetObject
};
