#ifndef __USB_MTP_H
#define __USB_MTP_H

#include "usbd_ioreq.h"

#define MTP_EPIN_ADDR                 0x81
#define MTP_EPOUT_ADDR                0x01
#define MTP_NOTIFICATION_IN_EP       0x82
#define MTP_MAX_PACKET               512

typedef struct {
    uint8_t filename[64];
    uint32_t storage_id;
    uint32_t object_compressed_size;
    uint16_t format;
    uint32_t parent_object;
} MTP_ObjectInfoTypedef;

typedef struct {
    uint16_t (*Init)(void);
    uint16_t (*DeInit)(void);
    uint16_t (*GetStorageIDs)(uint32_t *storage_ids_array, uint32_t *num_ids);
    uint16_t (*GetStorageInfo)(uint32_t storage_id, void *storage_info_buf);
    uint16_t (*GetObjectHandles)(uint32_t storage_id, uint32_t parent_object_handle,
                                 uint32_t format_code, uint32_t *handles_array, uint32_t *num_handles);
    uint16_t (*GetObjectInfo)(uint32_t object_handle, MTP_ObjectInfoTypedef *info);
    uint16_t (*GetObject)(uint32_t object_handle, uint8_t *buffer, uint32_t offset,
                          uint32_t length, uint32_t *actual_length);
    uint16_t (*SendObjectInfo)(uint32_t storage_id, uint32_t parent, MTP_ObjectInfoTypedef *info);
    uint16_t (*SendObject)(uint32_t object_handle, uint32_t offset, uint32_t length,
                           uint8_t *buffer, uint32_t *written);
    uint16_t (*DeleteObject)(uint32_t object_handle);
} USBD_MTP_StorageTypeDef;

extern USBD_ClassTypeDef USBD_MTP;

uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops);

#endif /* __USB_MTP_H */
