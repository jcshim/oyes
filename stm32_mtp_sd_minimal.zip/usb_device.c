#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_mtp.h"
#include "usbd_mtp_if.h"

USBD_HandleTypeDef hUsbDeviceHS;

void MX_USB_DEVICE_Init(void)
{
  /* Init Device Library */
  if (USBD_Init(&hUsbDeviceHS, &MTP_Desc, DEVICE_FS) != USBD_OK)
  {
    Error_Handler();
  }

  /* Register the MTP class */
  if (USBD_RegisterClass(&hUsbDeviceHS, &USBD_MTP) != USBD_OK)
  {
    Error_Handler();
  }

  /* Register the storage callbacks */
  if (USBD_MTP_RegisterStorage(&hUsbDeviceHS, &USBD_MTP_fops) != USBD_OK)
  {
    Error_Handler();
  }

  /* Start the USB Device */
  if (USBD_Start(&hUsbDeviceHS) != USBD_OK)
  {
    Error_Handler();
  }
}
