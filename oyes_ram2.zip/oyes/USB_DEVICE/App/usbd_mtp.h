/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_mtp.h
  * @brief          : Header for usbd_mtp.c file (MTP custom class)
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __USBD_MTP_H
#define __USBD_MTP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_ioreq.h"
#include "usbd_def.h"

/* MTP endpoint addresses */
#define MTP_EPOUT_ADDR              0x01
#define MTP_EPIN_ADDR               0x81
#define MTP_NOTIFICATION_IN_EP      0x83

/* MTP endpoint packet size (default: FullSpeed 64 bytes) */
#define MTP_MAX_PACKET              64

/* MTP Class callbacks structure */
extern USBD_ClassTypeDef USBD_MTP;
#define USBD_MTP_CLASS &USBD_MTP

/* MTP Storage API 구조체 정의 */
typedef struct _USBD_MTP_Storage {
  uint8_t (*Init)(void);
  uint8_t (*DeInit)(void);

  uint16_t (*GetStorageIDs)(uint32_t *storage_ids_array, uint32_t *num_ids);
  uint16_t (*GetStorageInfo)(uint32_t storage_id, void *storage_info);

  uint16_t (*GetObjectHandles)(uint32_t storage_id, uint32_t parent_object_handle,
                                uint32_t format_code, uint32_t *handles_array, uint32_t *num_handles);

  uint16_t (*GetObjectInfo)(uint32_t handle, void *object_info);

  uint16_t (*GetObject)(uint32_t handle, uint8_t *buffer, uint32_t offset,
                        uint32_t length, uint32_t *actual_length);

  uint16_t (*SendObject)(uint32_t *handle, uint8_t *data, uint32_t length);
  uint16_t (*DeleteObject)(uint32_t handle);

} USBD_MTP_StorageTypeDef;


/* API to register storage functions */
uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops);

#ifdef __cplusplus
}
#endif

#endif /* __USBD_MTP_H */
