/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_mtp_if.h
  * @brief          : Header for usbd_mtp_if.c (RAM 기반 MTP 구현용)
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __USBD_MTP_IF_H__
#define __USBD_MTP_IF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_mtp.h"  // 기본 MTP 구조체 및 타입 정의

// 기본 MTP 파일 포맷 코드 정의
#define MTP_FORMAT_ASSOCIATION 0x3001  // 폴더
#define MTP_FORMAT_TEXT        0x3004  // 텍스트 파일

// MTP Object Info 구조체
typedef struct {
    char     filename[64];
    uint32_t object_compressed_size;
    uint32_t parent_object;
    uint16_t format;
    uint32_t storage_id;
} MTP_ObjectInfoTypedef;

// 함수 프로토타입
uint16_t MTP_GetStorageIDs(uint32_t *storage_ids_array, uint32_t *num_ids);
uint16_t MTP_GetStorageInfo(uint32_t storage_id, void *storage_info);
uint16_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t parent_object_handle,
                              uint32_t format_code, uint32_t *handles_array, uint32_t *num_handles);
uint16_t MTP_GetObjectInfo(uint32_t handle, void *info);
uint16_t MTP_GetObject(uint32_t handle, uint8_t *buffer, uint32_t offset,
                       uint32_t length, uint32_t *actual_length);

// 외부에서 접근 가능한 Storage 구조체
extern USBD_MTP_StorageTypeDef USBD_MTP_fops;

#ifdef __cplusplus
}
#endif

#endif /* __USBD_MTP_IF_H__ */
