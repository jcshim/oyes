/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_mtp_if.c
  * @brief          : MTP RAM 기반 구현 예제 (탐색기 표시용 구조 포함)
  ******************************************************************************
  */
/* USER CODE END Header */

#include "usbd_mtp_if.h"
#include <string.h>
#include <stdio.h>

#define MTP_FORMAT_EXIF_JPEG     0x3801
#define MTP_FORMAT_ASSOCIATION   0x3001

/// 가상 MTP 오브젝트 구조체 정의
typedef struct {
    uint32_t handle;
    uint32_t parent;
    const char* name;
    uint8_t is_folder;
    uint32_t size;
    uint8_t* data;
} MTP_Object;

/// 더미 데이터 (50바이트 이상)
uint8_t dummy_data[] = "Hello from STM32 MTP (RAM)! This is a RAM-only test file with extra text.";

MTP_Object mtp_objects[] = {
    { 0x0001, 0x00000000, "Root", 1, 0, NULL },                        // 루트 폴더 (parent = 0)
    //{ 0x0002, 0x0001, "Documents", 1, 0, NULL },                       // Documents 폴더
    { 0x0002, 0x0001, "test.jpg", 0, sizeof(dummy_data) - 1, dummy_data }  // 파일
};

const uint32_t mtp_object_count = sizeof(mtp_objects) / sizeof(MTP_Object);

uint16_t MTP_GetStorageIDs(uint32_t *storage_ids_array, uint32_t *num_ids)
{
    storage_ids_array[0] = 0x00010001;
    *num_ids = 1;
    return 0x2001;
}

uint16_t MTP_GetStorageInfo(uint32_t storage_id, void *storage_info)
{
    if (storage_id != 0x00010001)
        return 0x2004;

    uint8_t *buf = (uint8_t *)storage_info;

    buf[0] = 0x02; buf[1] = 0x00; // StorageType
    buf[2] = 0x02; buf[3] = 0x00; // FileSystemType
    buf[4] = 0x00; buf[5] = 0x00; // AccessCapability

    uint64_t max_capacity = 8 * 1024 * 1024;
    memcpy(&buf[6], &max_capacity, 8);

    uint64_t free_space = 5 * 1024 * 1024;
    memcpy(&buf[14], &free_space, 8);

    const char *desc = "STM32";
    uint8_t desc_len = strlen(desc);
    buf[22] = desc_len * 2 + 1;
    for (uint8_t i = 0; i < desc_len; i++) {
        buf[23 + i*2] = desc[i];
        buf[24 + i*2] = 0;
    }

    const char *label = "MTP";
    uint8_t label_len = strlen(label);
    uint8_t offset = 23 + desc_len * 2;
    buf[offset] = label_len * 2 + 1;
    for (uint8_t i = 0; i < label_len; i++) {
        buf[offset + 1 + i*2] = label[i];
        buf[offset + 2 + i*2] = 0;
    }

    return 0x2001;
}

uint16_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t parent_object_handle,
                              uint32_t format_code, uint32_t *handles_array, uint32_t *num_handles)
{
    uint32_t count = 0;
    for (uint32_t i = 0; i < mtp_object_count; i++) {
        if (parent_object_handle == 0xFFFFFFFF || mtp_objects[i].parent == parent_object_handle) {
            handles_array[count++] = mtp_objects[i].handle;
        }
    }
    *num_handles = count;
    return 0x2001;
}

uint16_t MTP_GetObjectInfo(uint32_t handle, void *info)
{
    MTP_ObjectInfoTypedef *obj = (MTP_ObjectInfoTypedef *)info;

    for (uint32_t i = 0; i < mtp_object_count; i++) {
        if (mtp_objects[i].handle == handle) {
            strncpy(obj->filename, mtp_objects[i].name, sizeof(obj->filename));
            obj->filename[sizeof(obj->filename)-1] = 0;
            obj->object_compressed_size = mtp_objects[i].size;
            obj->format = mtp_objects[i].is_folder ? MTP_FORMAT_ASSOCIATION : MTP_FORMAT_EXIF_JPEG;
            obj->parent_object = mtp_objects[i].parent;
            obj->storage_id = 0x00010001;
            return 0x2001;
        }
    }
    return 0x2009;
}

uint16_t MTP_GetObject(uint32_t handle, uint8_t *buffer, uint32_t offset,
                       uint32_t length, uint32_t *actual_length)
{
    for (uint32_t i = 0; i < mtp_object_count; i++) {
        if (mtp_objects[i].handle == handle && mtp_objects[i].data) {
            if (offset >= mtp_objects[i].size) {
                *actual_length = 0;
                return 0x2001;
            }
            uint32_t copy_len = ((offset + length) > mtp_objects[i].size)
                              ? (mtp_objects[i].size - offset)
                              : length;
            memcpy(buffer, mtp_objects[i].data + offset, copy_len);
            *actual_length = copy_len;
            return 0x2001;
        }
    }
    return 0x2009;
}

USBD_MTP_StorageTypeDef USBD_MTP_fops = {
    .Init              = NULL,
    .DeInit            = NULL,
    .GetStorageIDs     = MTP_GetStorageIDs,
    .GetStorageInfo    = MTP_GetStorageInfo,
    .GetObjectHandles  = MTP_GetObjectHandles,
    .GetObjectInfo     = MTP_GetObjectInfo,
    .GetObject         = MTP_GetObject,
    .SendObject        = NULL,
    .DeleteObject      = NULL
};
