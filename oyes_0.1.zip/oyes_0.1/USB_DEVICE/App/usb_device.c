#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_mtp.h"
#include "usbd_mtp_if.h"

USBD_HandleTypeDef hUsbDeviceHS;

/* USB Device initialization function */
void MX_USB_DEVICE_Init(void)
{
  /* Init Device Library, Add Supported Class and Start the library */
  if (USBD_Init(&hUsbDeviceHS, &FS_Desc, DEVICE_FS) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_RegisterClass(&hUsbDeviceHS, &USBD_MTP) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_MTP_RegisterInterface(&hUsbDeviceHS, &USBD_MTP_fops) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_Start(&hUsbDeviceHS) != USBD_OK)
  {
    Error_Handler();
  }
}
