#ifndef __USBD_MTP_IF_H__
#define __USBD_MTP_IF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_mtp.h"
#include "ff.h"     // FatFS
#include "string.h"
#include "stdint.h"

#define MAX_MTP_OBJECTS    100
#define MAX_FILENAME_LEN   64

/* Handle-to-File mapping structure */
typedef struct {
    uint32_t handle;
    char filepath[MAX_FILENAME_LEN];
    FILINFO finfo;
} MTP_Object;

typedef struct {
    uint32_t count;
    MTP_Object objects[MAX_MTP_OBJECTS];
} MTP_ObjectDB;

/* Exported variables */
extern USBD_MTP_ItfTypeDef USBD_MTP_fops;

/* Scanning / lookup helpers */
void MTP_ScanObjects(void);
MTP_Object* MTP_FindObjectByHandle(uint32_t handle);

#ifdef __cplusplus
}
#endif

#endif /* __USBD_MTP_IF_H__ */
