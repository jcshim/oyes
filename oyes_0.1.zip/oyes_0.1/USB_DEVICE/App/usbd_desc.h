#ifndef __USBD_DESC_H
#define __USBD_DESC_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "usbd_def.h"

/** USB descriptor functions */
extern USBD_DescriptorsTypeDef FS_Desc;

#define USB_SIZ_STRING_SERIAL  0x1A

/** Function prototypes */
uint8_t *USBD_FS_DeviceDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_LangIDStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_ManufacturerStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_ProductStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_SerialStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_ConfigStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);
uint8_t *USBD_FS_InterfaceStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length);

#ifdef __cplusplus
}
#endif

#endif /* __USBD_DESC_H */
