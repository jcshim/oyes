#include "usbd_mtp_if.h"
#include "ff.h"
#include "stdio.h"

static MTP_ObjectDB mtp_db;

/* UTF-16LE conversion helper */
static uint16_t *utf16le_copy(char *src, uint16_t *dst)
{
    uint16_t *p = dst;
    while (*src && (p - dst) < 128) {
        *p++ = (uint8_t)*src++;
    }
    return dst;
}

/* Scan root directory and fill mtp_db */
void MTP_ScanObjects(void)
{
    DIR dir;
    FILINFO fno;
    uint32_t handle = 1;

    mtp_db.count = 0;
    if (f_opendir(&dir, "/") != FR_OK) return;

    while (mtp_db.count < MAX_MTP_OBJECTS && f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
        if (fno.fattrib & AM_DIR) continue; // Skip directories
        snprintf(mtp_db.objects[mtp_db.count].filepath, MAX_FILENAME_LEN, "/%s", fno.fname);
        memcpy(&mtp_db.objects[mtp_db.count].finfo, &fno, sizeof(FILINFO));
        mtp_db.objects[mtp_db.count].handle = handle++;
        mtp_db.count++;
    }

    f_closedir(&dir);
}

MTP_Object* MTP_FindObjectByHandle(uint32_t handle)
{
    for (uint32_t i = 0; i < mtp_db.count; i++) {
        if (mtp_db.objects[i].handle == handle)
            return &mtp_db.objects[i];
    }
    return NULL;
}

/* MTP Interface Implementations */

static uint32_t MTP_GetDeviceInfo(uint8_t *buf, uint16_t *len)
{
    static const uint8_t info[] = {
        0x18, 0x00,             // Length
        0x00, 0x01,             // Standard Version
        0x00, 0x00,             // Vendor Extension ID
        0x06, 0x00,             // MTP Version
        0x00, 0x00,             // Functional Mode
        0x01,                   // Number of operations supported
        0x01, 0x10,             // Operation code (example)
        0x01,                   // Manufacturer string ID
        0x02,                   // Model string ID
        0x03,                   // Device version string ID
        0x04                    // Serial number string ID
    };
    memcpy(buf, info, sizeof(info));
    *len = sizeof(info);
    return USBD_OK;
}

static uint32_t MTP_OpenSession(uint32_t session_id)
{
    (void)session_id;
    MTP_ScanObjects(); // Rescan every session
    return USBD_OK;
}

static uint32_t MTP_CloseSession(void)
{
    return USBD_OK;
}

static uint32_t MTP_GetStorageIDs(uint8_t *buf, uint16_t *len)
{
    buf[0] = 0x04;  // length
    buf[1] = 0x01;  // number of storage IDs
    buf[2] = 0x01;  // ID = 0x00010001
    buf[3] = 0x00;
    *len = 4;
    return USBD_OK;
}

static uint32_t MTP_GetStorageInfo(uint32_t storage_id, uint8_t *buf, uint16_t *len)
{
    (void)storage_id;

    uint32_t total = 16 * 1024 * 1024; // 16MB total
    uint32_t free = 8 * 1024 * 1024;   // 8MB free

    uint8_t *p = buf;
    *(uint16_t*)p = 0x0002; p += 2; // Storage Type
    *(uint16_t*)p = 0x0002; p += 2; // File system
    *(uint32_t*)p = 0; p += 4;      // Access capability
    *(uint64_t*)p = total; p += 8;
    *(uint64_t*)p = free; p += 8;
    *(uint32_t*)p = 512; p += 4;    // block size

    *p++ = 0; // Storage description
    *p++ = 0; // Volume label

    *len = p - buf;
    return USBD_OK;
}

static uint32_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t format_code, uint32_t association, uint8_t *buf, uint16_t *len)
{
    (void)storage_id;
    (void)format_code;
    (void)association;

    uint32_t *p = (uint32_t *)buf;
    p[0] = mtp_db.count;

    for (uint32_t i = 0; i < mtp_db.count; i++) {
        p[i + 1] = mtp_db.objects[i].handle;
    }

    *len = (mtp_db.count + 1) * sizeof(uint32_t);
    return USBD_OK;
}

static uint32_t MTP_GetObjectInfo(uint32_t handle, uint8_t *buf, uint16_t *len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    uint8_t *p = buf;
    memset(p, 0, 128);

    *(uint32_t*)p = obj->handle;  p += 4;
    *(uint16_t*)p = 0x3000;       p += 2; // format: undefined
    *(uint16_t*)p = 0;            p += 2; // protection
    *(uint32_t*)p = obj->finfo.fsize; p += 4;
    *(uint32_t*)p = 0; p += 4; // thumb size
    *(uint32_t*)p = 0; p += 4; // thumb format
    *(uint32_t*)p = 0; p += 4; // image width
    *(uint32_t*)p = 0; p += 4; // image height
    *(uint32_t*)p = 0; p += 4; // image bitdepth
    *(uint32_t*)p = 0; p += 4; // parent obj
    *(uint32_t*)p = 0x00010001; p += 4; // storage ID

    *p++ = strlen(obj->finfo.fname);  // 문자열 길이 (UTF-8 기준)

    char *name = obj->finfo.fname;
    while (*name) {
        *p++ = *name++;     // 1바이트 문자
        *p++ = 0x00;        // UTF-16LE용 null padding
    }

    *len = p - buf;
    return USBD_OK;
}

static uint32_t MTP_GetObject(uint32_t handle, uint8_t *buf, uint32_t offset, uint32_t maxlen, uint32_t *xfer_len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    FIL file;
    if (f_open(&file, obj->filepath, FA_READ) != FR_OK) return USBD_FAIL;
    if (f_lseek(&file, offset) != FR_OK) { f_close(&file); return USBD_FAIL; }

    UINT br = 0;
    FRESULT res = f_read(&file, buf, maxlen, &br);
    f_close(&file);
    if (res != FR_OK) return USBD_FAIL;

    *xfer_len = br;
    return USBD_OK;
}

/* Exported interface */
USBD_MTP_ItfTypeDef USBD_MTP_fops = {
    MTP_GetDeviceInfo,
    MTP_OpenSession,
    MTP_CloseSession,
    MTP_GetStorageIDs,
    MTP_GetStorageInfo,
    MTP_GetObjectHandles,
    MTP_GetObjectInfo,
    MTP_GetObject
};
