#include "usbd_mtp.h"
#include "usbd_ctlreq.h"
#include "string.h"

USBD_ClassTypeDef USBD_MTP;

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t *USBD_MTP_GetCfgDesc(uint16_t *length);

static USBD_MTP_ItfTypeDef *mtp_fops;

/**
  * @brief  Register interface
  */
uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops)
{
  if (fops == NULL) return USBD_FAIL;
  mtp_fops = fops;
  return USBD_OK;
}

/**
  * @brief  Init handler
  */
static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  UNUSED(pdev);
  UNUSED(cfgidx);
  return USBD_OK;
}

/**
  * @brief  DeInit handler
  */
static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  UNUSED(pdev);
  UNUSED(cfgidx);
  return USBD_OK;
}

/**
  * @brief  MTP class request dispatcher
  */
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
  uint8_t buffer[512];
  uint16_t length = 0;
  uint32_t result = USBD_FAIL;

  if ((req->bmRequest & 0x60) == 0x20)  // Class request
  {
    switch (req->bRequest)
    {
    case MTP_REQ_GET_DEVICE_STATUS:
      buffer[0] = 0x00;
      buffer[1] = 0x00;
      length = 2;
      result = USBD_OK;
      break;

    case 0x01: // GetDeviceInfo
      if (mtp_fops && mtp_fops->GetDeviceInfo)
        result = mtp_fops->GetDeviceInfo(buffer, &length);
      break;

    case 0x02: // GetStorageIDs
      if (mtp_fops && mtp_fops->GetStorageIDs)
        result = mtp_fops->GetStorageIDs(buffer, &length);
      break;

    case 0x03: // GetStorageInfo
      if (mtp_fops && mtp_fops->GetStorageInfo)
        result = mtp_fops->GetStorageInfo(0x00010001, buffer, &length);
      break;

    case 0x04: // GetObjectHandles
      if (mtp_fops && mtp_fops->GetObjectHandles)
        result = mtp_fops->GetObjectHandles(0x00010001, 0, 0, buffer, &length);
      break;

    case 0x05: // GetObjectInfo
      if (mtp_fops && mtp_fops->GetObjectInfo)
        result = mtp_fops->GetObjectInfo(req->wValue, buffer, &length);
      break;

    case 0x06: // GetObject
    {
      uint32_t xfer_len = 0;
      if (mtp_fops && mtp_fops->GetObject)
        result = mtp_fops->GetObject(req->wValue, buffer, 0, sizeof(buffer), &xfer_len);
      length = xfer_len;
      break;
    }

    case 0x0F: // OpenSession
      if (mtp_fops && mtp_fops->OpenSession)
        result = mtp_fops->OpenSession(req->wValue);
      length = 0;
      break;

    case 0x10: // CloseSession
      if (mtp_fops && mtp_fops->CloseSession)
        result = mtp_fops->CloseSession();
      length = 0;
      break;

    default:
      USBD_CtlError(pdev, req);
      return USBD_FAIL;
    }

    if (result == USBD_OK)
    {
      USBD_CtlSendData(pdev, buffer, length);
      return USBD_OK;
    }
    else
    {
      USBD_CtlError(pdev, req);
      return USBD_FAIL;
    }
  }

  return USBD_OK;
}

/**
  * @brief  Configuration descriptor
  */
static uint8_t USBD_MTP_CfgDesc[USB_MTP_CONFIG_DESC_SIZ] =
{
  0x09,                       // bLength
  USB_DESC_TYPE_CONFIGURATION,
  USB_MTP_CONFIG_DESC_SIZ, 0x00,
  0x01,                       // bNumInterfaces
  0x01,                       // bConfigurationValue
  0x00,                       // iConfiguration
  0x80,                       // bmAttributes (Bus powered)
  0xFA,                       // MaxPower (500mA)

  // Interface Descriptor
  0x09,                       // bLength
  USB_DESC_TYPE_INTERFACE,
  0x00,                       // bInterfaceNumber
  0x00,                       // bAlternateSetting
  0x02,                       // bNumEndpoints
  USB_MTP_CLASS_CODE,
  USB_MTP_SUBCLASS_CODE,
  USB_MTP_PROTOCOL_CODE,
  0x00,

  // Endpoint IN
  0x07,
  USB_DESC_TYPE_ENDPOINT,
  MTP_IN_EP,
  0x02,
  LOBYTE(MTP_DATA_MAX_PACKET_SIZE),
  HIBYTE(MTP_DATA_MAX_PACKET_SIZE),
  0x00,

  // Endpoint OUT
  0x07,
  USB_DESC_TYPE_ENDPOINT,
  MTP_OUT_EP,
  0x02,
  LOBYTE(MTP_DATA_MAX_PACKET_SIZE),
  HIBYTE(MTP_DATA_MAX_PACKET_SIZE),
  0x00,
};

/**
  * @brief  Return configuration descriptor
  */
static uint8_t *USBD_MTP_GetCfgDesc(uint16_t *length)
{
  *length = sizeof(USBD_MTP_CfgDesc);
  return USBD_MTP_CfgDesc;
}

/* MTP Class callbacks structure */
USBD_ClassTypeDef USBD_MTP =
{
  USBD_MTP_Init,
  USBD_MTP_DeInit,
  USBD_MTP_Setup,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  USBD_MTP_GetCfgDesc,
  USBD_MTP_GetCfgDesc,
  USBD_MTP_GetCfgDesc,
  NULL
};
