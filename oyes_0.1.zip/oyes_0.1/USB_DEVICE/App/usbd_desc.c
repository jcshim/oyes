#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_conf.h"

#define USBD_VID  0x0483
#define USBD_PID  0x5740

/* USB Standard Device Descriptor */
__ALIGN_BEGIN uint8_t USBD_FS_DeviceDesc[USB_LEN_DEV_DESC] __ALIGN_END =
{
  0x12,                       // bLength
  USB_DESC_TYPE_DEVICE,      // bDescriptorType
  0x00, 0x02,                 // bcdUSB 2.00
  0x00,                       // bDeviceClass (defined in interface descriptor)
  0x00,                       // bDeviceSubClass
  0x00,                       // bDeviceProtocol
  USB_MAX_EP0_SIZE,          // bMaxPacketSize
  LOBYTE(USBD_VID), HIBYTE(USBD_VID), // idVendor
  LOBYTE(USBD_PID), HIBYTE(USBD_PID), // idProduct
  0x00, 0x01,                 // bcdDevice
  USBD_IDX_MFC_STR,          // Index of manufacturer string
  USBD_IDX_PRODUCT_STR,      // Index of product string
  USBD_IDX_SERIAL_STR,       // Index of serial number string
  USBD_MAX_NUM_CONFIGURATION // bNumConfigurations
};

/* Language ID */
__ALIGN_BEGIN uint8_t USBD_LangIDDesc[USB_LEN_LANGID_STR_DESC] __ALIGN_END =
{
  USB_LEN_LANGID_STR_DESC,
  USB_DESC_TYPE_STRING,
  LOBYTE(0x0409), HIBYTE(0x0409) // English (US)
};

/* String Descriptors */
#define USBD_MANUFACTURER_STRING     "Andong Univ."
#define USBD_PRODUCT_FS_STRING       "SD MTP Device"
#define USBD_SERIALNUMBER_FS_STRING  "SDMTP001"
#define USBD_CONFIGURATION_FS_STRING "MTP Config"
#define USBD_INTERFACE_FS_STRING     "MTP Interface"

uint8_t USBD_StrDesc[USBD_MAX_STR_DESC_SIZ];

/* Helper to convert ASCII to UTF-16LE string descriptor */
static void USBD_GetCustomString(const char *desc, uint8_t *unicode, uint16_t *len)
{
  uint8_t idx = 0;
  if (desc == NULL)
  {
    *len = 0;
    return;
  }

  unicode[idx++] = (strlen(desc) * 2 + 2);
  unicode[idx++] = USB_DESC_TYPE_STRING;

  while (*desc != '\0')
  {
    unicode[idx++] = *desc++;
    unicode[idx++] = 0x00;
  }

  *len = idx;
}

/* USB Descriptors structure */
USBD_DescriptorsTypeDef FS_Desc =
{
  USBD_FS_DeviceDescriptor,
  USBD_FS_LangIDStrDescriptor,
  USBD_FS_ManufacturerStrDescriptor,
  USBD_FS_ProductStrDescriptor,
  USBD_FS_SerialStrDescriptor,
  USBD_FS_ConfigStrDescriptor,
  USBD_FS_InterfaceStrDescriptor
};

/* Standard Descriptors */

uint8_t *USBD_FS_DeviceDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  *length = sizeof(USBD_FS_DeviceDesc);
  return USBD_FS_DeviceDesc;
}

uint8_t *USBD_FS_LangIDStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  *length = sizeof(USBD_LangIDDesc);
  return USBD_LangIDDesc;
}

uint8_t *USBD_FS_ManufacturerStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  USBD_GetCustomString(USBD_MANUFACTURER_STRING, USBD_StrDesc, length);
  return USBD_StrDesc;
}

uint8_t *USBD_FS_ProductStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  USBD_GetCustomString(USBD_PRODUCT_FS_STRING, USBD_StrDesc, length);
  return USBD_StrDesc;
}

uint8_t *USBD_FS_SerialStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  USBD_GetCustomString(USBD_SERIALNUMBER_FS_STRING, USBD_StrDesc, length);
  return USBD_StrDesc;
}

uint8_t *USBD_FS_ConfigStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  USBD_GetCustomString(USBD_CONFIGURATION_FS_STRING, USBD_StrDesc, length);
  return USBD_StrDesc;
}

uint8_t *USBD_FS_InterfaceStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  UNUSED(speed);
  USBD_GetCustomString(USBD_INTERFACE_FS_STRING, USBD_StrDesc, length);
  return USBD_StrDesc;
}
