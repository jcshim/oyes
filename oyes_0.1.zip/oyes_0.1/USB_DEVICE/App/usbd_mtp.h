#ifndef __USBD_MTP_H
#define __USBD_MTP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_ioreq.h"
#include "stdint.h"

/* MTP class-specific request codes */
#define MTP_REQ_CANCEL                0x64
#define MTP_REQ_GET_EXT_EVENT_DATA   0x65
#define MTP_REQ_RESET                0x66
#define MTP_REQ_GET_DEVICE_STATUS    0x67

/* Endpoint settings */
#define MTP_IN_EP                    0x81  /* EP1 IN  */
#define MTP_OUT_EP                   0x01  /* EP1 OUT */

#define MTP_DATA_HS_MAX_PACKET_SIZE  512
#define MTP_DATA_FS_MAX_PACKET_SIZE  64

#if (USBD_MAX_EP0_SIZE == 64)
#define MTP_DATA_MAX_PACKET_SIZE     MTP_DATA_FS_MAX_PACKET_SIZE
#else
#define MTP_DATA_MAX_PACKET_SIZE     MTP_DATA_HS_MAX_PACKET_SIZE
#endif

#define USB_MTP_CONFIG_DESC_SIZ      32

#define USB_MTP_CLASS_CODE           0x06  // Still Image
#define USB_MTP_SUBCLASS_CODE        0x01
#define USB_MTP_PROTOCOL_CODE        0x01

typedef enum {
  MTP_IDLE = 0,
  MTP_DATA_IN,
  MTP_DATA_OUT,
  MTP_STATUS_IN,
  MTP_RECEIVING_DATA,
  MTP_SENDING_DATA
} MTP_StateTypeDef;

/* Interface function table */
typedef struct {
  uint32_t (*GetDeviceInfo)(uint8_t *buf, uint16_t *len);
  uint32_t (*OpenSession)(uint32_t session_id);
  uint32_t (*CloseSession)(void);
  uint32_t (*GetStorageIDs)(uint8_t *buf, uint16_t *len);
  uint32_t (*GetStorageInfo)(uint32_t storage_id, uint8_t *buf, uint16_t *len);
  uint32_t (*GetObjectHandles)(uint32_t storage_id, uint32_t format_code, uint32_t association, uint8_t *buf, uint16_t *len);
  uint32_t (*GetObjectInfo)(uint32_t handle, uint8_t *buf, uint16_t *len);
  uint32_t (*GetObject)(uint32_t handle, uint8_t *buf, uint32_t offset, uint32_t maxlen, uint32_t *xfer_len);
} USBD_MTP_ItfTypeDef;

/* Internal state handle */
typedef struct {
  uint8_t data_buffer[MTP_DATA_MAX_PACKET_SIZE];
  uint8_t cmd_buffer[MTP_DATA_MAX_PACKET_SIZE];
  uint8_t resp_buffer[MTP_DATA_MAX_PACKET_SIZE];
  uint32_t data_length;
  uint32_t data_offset;
  uint32_t total_length;
  uint32_t current_handle;
  uint32_t session_id;
  MTP_StateTypeDef state;
  USBD_MTP_ItfTypeDef *fops;
} USBD_MTP_HandleTypeDef;

/* USB MTP interface class driver */
extern USBD_ClassTypeDef USBD_MTP;

uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops);

#ifdef __cplusplus
}
#endif

#endif /* __USBD_MTP_H */
