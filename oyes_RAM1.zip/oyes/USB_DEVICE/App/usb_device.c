/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usb_device.c
  * @brief          : USB Device initialization source (MTP 전용)
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_mtp.h"
#include "usbd_mtp_if.h"

/* USB Device Core handle declaration */
USBD_HandleTypeDef hUsbDeviceHS;

/**
  * @brief Initialize USB device, register MTP class and storage interface
  * @retval None
  */
void MX_USB_DEVICE_Init(void)
{
  /* Enable USB voltage detector (필수) */
  HAL_PWREx_EnableUSBVoltageDetector();

  /* Initialize USB Device stack */
  if (USBD_Init(&hUsbDeviceHS, &HS_Desc, DEVICE_HS) != USBD_OK)
  {
    Error_Handler();
  }

  /* Register MTP class with USB Device Core */
  if (USBD_RegisterClass(&hUsbDeviceHS, &USBD_MTP) != USBD_OK)
  {
    Error_Handler();
  }

  /* Register MTP storage interface (RAM 기반 또는 SD 카드 기반) */
  if (USBD_MTP_RegisterStorage(&hUsbDeviceHS, &USBD_MTP_fops) != USBD_OK)
  {
    Error_Handler();
  }

  /* Start USB Device stack */
  if (USBD_Start(&hUsbDeviceHS) != USBD_OK)
  {
    Error_Handler();
  }
}
