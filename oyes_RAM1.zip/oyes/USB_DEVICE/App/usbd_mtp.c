/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_mtp.c
  * @brief          : MTP custom class source file
  ******************************************************************************
  */
/* USER CODE END Header */

#include "usbd_mtp.h"
#include "usbd_ctlreq.h"
#include "usbd_mtp_if.h"

#define MTP_REQ_GET_DEVICE_INFO     0x1001
#define MTP_REQ_GET_STORAGE_IDS     0x1004
#define MTP_REQ_GET_STORAGE_INFO    0x1005
#define MTP_REQ_GET_OBJECT_HANDLES  0x1007
#define MTP_REQ_GET_OBJECT_INFO     0x1008
#define MTP_REQ_GET_OBJECT          0x1009

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length);

USBD_ClassTypeDef USBD_MTP = {
    USBD_MTP_Init,
    USBD_MTP_DeInit,
    USBD_MTP_Setup,
    NULL,
    NULL,
    USBD_MTP_DataIn,
    USBD_MTP_DataOut,
    NULL,
    NULL,
    USBD_MTP_GetCfgDesc,
    USBD_MTP_GetCfgDesc,
    USBD_MTP_GetCfgDesc
};

static USBD_MTP_StorageTypeDef *mtp_fops;

__ALIGN_BEGIN static uint8_t USBD_MTP_CfgDesc[] __ALIGN_END = {
    0x09, USB_DESC_TYPE_CONFIGURATION, 0x27, 0x00, 0x01, 0x01, 0x00, 0xC0, 0x32,
    0x09, USB_DESC_TYPE_INTERFACE, 0x00, 0x00, 0x03, 0x06, 0x01, 0x01, 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_EPOUT_ADDR, 0x02, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_EPIN_ADDR, 0x02, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_NOTIFICATION_IN_EP, 0x03, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0xFF
};

static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length)
{
    *length = sizeof(USBD_MTP_CfgDesc);
    return USBD_MTP_CfgDesc;
}

uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops)
{
    mtp_fops = fops;
    return USBD_OK;
}

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_OpenEP(pdev, MTP_EPIN_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_EPOUT_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_NOTIFICATION_IN_EP, USBD_EP_TYPE_INTR, MTP_MAX_PACKET);
    return USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_CloseEP(pdev, MTP_EPIN_ADDR);
    USBD_LL_CloseEP(pdev, MTP_EPOUT_ADDR);
    USBD_LL_CloseEP(pdev, MTP_NOTIFICATION_IN_EP);
    return USBD_OK;
}

static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
    // 이 부분은 MTP 명령 파싱 구현 예정
    return USBD_OK;
}

static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    return USBD_OK;
}

static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    return USBD_OK;
}
