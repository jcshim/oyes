/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usb_device.h
  * @brief          : Header for usb_device.c file (MTP 전용)
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __USB_DEVICE_H
#define __USB_DEVICE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_def.h"

/* USB Device Core handle declaration */
extern USBD_HandleTypeDef hUsbDeviceHS;

/**
  * @brief Initialize USB device and register MTP class.
  * @retval None
  */
void MX_USB_DEVICE_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* __USB_DEVICE_H */
