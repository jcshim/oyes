/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_mtp.c
  * @brief          : MTP custom class source file (with Setup handler)
  ******************************************************************************
  */
/* USER CODE END Header */

#include "usbd_mtp.h"
#include "usbd_ctlreq.h"
#include "usbd_mtp_if.h"
#include <string.h>

#define MTP_REQ_GET_DEVICE_INFO     0x1001
#define MTP_REQ_GET_STORAGE_IDS     0x1004
#define MTP_REQ_GET_STORAGE_INFO    0x1005
#define MTP_REQ_GET_OBJECT_HANDLES  0x1007
#define MTP_REQ_GET_OBJECT_INFO     0x1008
#define MTP_REQ_GET_OBJECT          0x1009

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
//static uint8_t *USBD_MTP_FSConfigDesc(USBD_HandleTypeDef *pdev, uint8_t speed);
static uint8_t *USBD_MTP_FSConfigDesc(uint16_t *length);

USBD_ClassTypeDef USBD_MTP = {
    USBD_MTP_Init,
    USBD_MTP_DeInit,
    USBD_MTP_Setup,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    USBD_MTP_FSConfigDesc,
    USBD_MTP_FSConfigDesc,
    USBD_MTP_FSConfigDesc,
    NULL
};

static USBD_MTP_StorageTypeDef *mtp_fops;

__ALIGN_BEGIN static uint8_t USBD_MTP_CfgDesc[] __ALIGN_END = {
    0x09, USB_DESC_TYPE_CONFIGURATION, 0x27, 0x00, 0x01, 0x01, 0x00, 0xC0, 0x32,
    0x09, USB_DESC_TYPE_INTERFACE, 0x00, 0x00, 0x03, 0x06, 0x01, 0x01, 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_EPOUT_ADDR, 0x02, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_EPIN_ADDR, 0x02, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0x00,
    0x07, USB_DESC_TYPE_ENDPOINT, MTP_NOTIFICATION_IN_EP, 0x03, LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET), 0xFF
};

static uint8_t *USBD_MTP_FSConfigDesc(uint16_t *length)
{
    //UNUSED(pdev);
    //UNUSED(speed);
    *length = sizeof(USBD_MTP_CfgDesc);  // 반환 길이 필수!
    //return (uint8_t)((uintptr_t)USBD_MTP_CfgDesc);
    return USBD_MTP_CfgDesc;
}

uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops)
{
    mtp_fops = fops;
    return USBD_OK;
}

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_OpenEP(pdev, MTP_EPIN_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_EPOUT_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_NOTIFICATION_IN_EP, USBD_EP_TYPE_INTR, MTP_MAX_PACKET);
    return USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_CloseEP(pdev, MTP_EPIN_ADDR);
    USBD_LL_CloseEP(pdev, MTP_EPOUT_ADDR);
    USBD_LL_CloseEP(pdev, MTP_NOTIFICATION_IN_EP);
    return USBD_OK;
}

static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
    static uint8_t ctrl_buf[512];
    uint32_t object_ids[10];

    switch (req->wValue) {
    case MTP_REQ_GET_DEVICE_INFO:
    {
        const uint8_t device_info[] = {
            0x00, 0x01,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00,
            0x00,
            0x00,
            0x02, 0x00, 0x01, 0x10, 0x04, 0x10,
            0x01, 0x00, 0x00, 0x40,
            0x01, 0x00, 0xD1, 0x50,
            0x01, 0x00, 0x00,
            0x01, 0x00, 0x00,
            0x22, 'S', 0, 'T', 0, 'M', 0, 'i', 0, 'c', 0, 'r', 0, 'o', 0, 'e', 0, 'l', 0, 'e', 0, 'c', 0, 't', 0, 'r', 0, 'o', 0, 'n', 0, 'i', 0, 'c', 0, 's', 0,
            0x18, 'S', 0, 'T', 0, 'M', 0, '3', 0, '2', 0, '-', 0, 'M', 0, 'T', 0, 'P', 0, '-', 0, 'D', 0, 'E', 0, 'V', 0,
            0x0C, '1', 0, '.', 0, '2', 0, '.', 0, '3', 0,
            0x14, '2', 0, '0', 0, '2', 0, '5', 0, '0', 0, '7', 0, '1', 0, '8', 0,
        };
        USBD_CtlSendData(pdev, (uint8_t*)device_info, sizeof(device_info));
    }
    break;

    case MTP_REQ_GET_STORAGE_IDS:
        if (mtp_fops->GetStorageIDs) {
            uint32_t count = 0;
            mtp_fops->GetStorageIDs(object_ids, &count);
            memcpy(ctrl_buf, object_ids, count * sizeof(uint32_t));
            USBD_CtlSendData(pdev, ctrl_buf, count * sizeof(uint32_t));
        }
        break;

    case MTP_REQ_GET_STORAGE_INFO:
        if (mtp_fops->GetStorageInfo) {
            mtp_fops->GetStorageInfo(req->wIndex, ctrl_buf);
            USBD_CtlSendData(pdev, ctrl_buf, 128);
        }
        break;

    case MTP_REQ_GET_OBJECT_HANDLES:
        if (mtp_fops->GetObjectHandles) {
            uint32_t num_handles = 0;
            mtp_fops->GetObjectHandles(0x00010001, 0xFFFFFFFF, 0, object_ids, &num_handles);
            memcpy(ctrl_buf, object_ids, num_handles * sizeof(uint32_t));
            USBD_CtlSendData(pdev, ctrl_buf, num_handles * sizeof(uint32_t));
        }
        break;

    case MTP_REQ_GET_OBJECT_INFO:
        if (mtp_fops->GetObjectInfo) {
            mtp_fops->GetObjectInfo(req->wIndex, ctrl_buf);
            USBD_CtlSendData(pdev, ctrl_buf, 256);
        }
        break;

    case MTP_REQ_GET_OBJECT:
        if (mtp_fops->GetObject) {
            uint32_t read_len = 0;
            mtp_fops->GetObject(req->wIndex, ctrl_buf, 0, sizeof(ctrl_buf), &read_len);
            USBD_CtlSendData(pdev, ctrl_buf, read_len);
        }
        break;

    default:
        USBD_CtlError(pdev, req);
        return USBD_FAIL;
    }
    return USBD_OK;
}
