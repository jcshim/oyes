#include <stddef.h>
#include "usbd_mtp_if.h"

USBD_MTP_StorageTypeDef USBD_MTP_fops =
{
    .Init = NULL,
    .DeInit = NULL,
    .GetObjectHandles = NULL,
    .GetObject = NULL,
    .SendObject = NULL,
    .DeleteObject = NULL
};
