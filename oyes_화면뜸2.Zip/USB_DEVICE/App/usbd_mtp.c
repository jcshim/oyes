#include "usbd_mtp.h"
#include "usbd_ctlreq.h"

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t *USBD_MTP_GetCfgDesc(uint16_t *length);

USBD_ClassTypeDef USBD_MTP =
{
    USBD_MTP_Init,
    USBD_MTP_DeInit,
    USBD_MTP_Setup,
    NULL,
    NULL,
    USBD_MTP_DataIn,
    USBD_MTP_DataOut,
    NULL,
    NULL,
    USBD_MTP_GetCfgDesc,
    USBD_MTP_GetCfgDesc,
    USBD_MTP_GetCfgDesc
};

__ALIGN_BEGIN static uint8_t USBD_MTP_CfgDesc[USB_MTP_CONFIG_DESC_SIZ] __ALIGN_END =
{
    0x09,                       // bLength
    USB_DESC_TYPE_CONFIGURATION,// bDescriptorType
    USB_MTP_CONFIG_DESC_SIZ, 0x00, // wTotalLength
    0x01,                       // bNumInterfaces
    0x01,                       // bConfigurationValue
    0x00,                       // iConfiguration
    0xC0,                       // bmAttributes
    0x32,                       // bMaxPower

    // Interface Descriptor
    0x09,
    USB_DESC_TYPE_INTERFACE,
    0x00,                       // bInterfaceNumber
    0x00,                       // bAlternateSetting
    0x03,                       // bNumEndpoints
    0x06,                       // bInterfaceClass (Still Image)
    0x01,                       // bInterfaceSubClass
    0x01,                       // bInterfaceProtocol (Picture Transfer Protocol - PTP)
    0x00,                       // iInterface

    // Endpoint OUT
    0x07,
    USB_DESC_TYPE_ENDPOINT,
    MTP_EPOUT_ADDR,
    0x02,
    LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET),
    0x00,

    // Endpoint IN
    0x07,
    USB_DESC_TYPE_ENDPOINT,
    MTP_EPIN_ADDR,
    0x02,
    LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET),
    0x00,

    // Endpoint Notification (Interrupt IN)
    0x07,
    USB_DESC_TYPE_ENDPOINT,
    MTP_NOTIFICATION_IN_EP,
    0x03,
    LOBYTE(MTP_MAX_PACKET), HIBYTE(MTP_MAX_PACKET),
    0xFF
};

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_OpenEP(pdev, MTP_EPIN_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_EPOUT_ADDR, USBD_EP_TYPE_BULK, MTP_MAX_PACKET);
    USBD_LL_OpenEP(pdev, MTP_NOTIFICATION_IN_EP, USBD_EP_TYPE_INTR, MTP_MAX_PACKET);
    return USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    USBD_LL_CloseEP(pdev, MTP_EPIN_ADDR);
    USBD_LL_CloseEP(pdev, MTP_EPOUT_ADDR);
    USBD_LL_CloseEP(pdev, MTP_NOTIFICATION_IN_EP);
    return USBD_OK;
}

static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
    return USBD_OK;
}

static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    return USBD_OK;
}

static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    return USBD_OK;
}

static uint8_t *USBD_MTP_GetCfgDesc(uint16_t *length)
{
    *length = sizeof(USBD_MTP_CfgDesc);
    return USBD_MTP_CfgDesc;
}

#include "usbd_mtp_if.h"

static USBD_MTP_StorageTypeDef *mtp_fops;

uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops)
{
  mtp_fops = fops;
  return USBD_OK;
}
