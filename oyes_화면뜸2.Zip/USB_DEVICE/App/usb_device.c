#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_mtp.h"
#include "usbd_mtp_if.h"

/* USB Device Core handle declaration */
USBD_HandleTypeDef hUsbDeviceHS;

void MX_USB_DEVICE_Init(void)
{
  HAL_PWREx_EnableUSBVoltageDetector();

  if (USBD_Init(&hUsbDeviceHS, &HS_Desc, DEVICE_HS) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_RegisterClass(&hUsbDeviceHS, &USBD_MTP) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_MTP_RegisterStorage(&hUsbDeviceHS, &USBD_MTP_fops) != USBD_OK)
  {
    Error_Handler();
  }

  if (USBD_Start(&hUsbDeviceHS) != USBD_OK)
  {
    Error_Handler();
  }
}
