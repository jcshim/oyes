#ifndef __USBD_MTP_IF_H
#define __USBD_MTP_IF_H

typedef struct _USBD_MTP_StorageTypeDef
{
    int (* Init)(void);
    int (* DeInit)(void);
    int (* GetObjectHandles)(void);
    int (* GetObject)(void);
    int (* SendObject)(void);
    int (* DeleteObject)(void);
} USBD_MTP_StorageTypeDef;

extern USBD_MTP_StorageTypeDef USBD_MTP_fops;

#endif /* __USBD_MTP_IF_H */
