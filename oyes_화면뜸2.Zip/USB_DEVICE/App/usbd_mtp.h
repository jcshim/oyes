#ifndef __USBD_MTP_H
#define __USBD_MTP_H

#include "usbd_ioreq.h"
#include "usbd_mtp_if.h"  // Add this include for storage interface

#define MTP_EPIN_ADDR                 0x81
#define MTP_EPOUT_ADDR                0x01
#define MTP_NOTIFICATION_IN_EP       0x82

#define USB_MTP_CONFIG_DESC_SIZ      32
#define USB_MTP_DESC_SIZ             32

#define MTP_MAX_PACKET               64

extern USBD_ClassTypeDef USBD_MTP;
#define USBD_MTP_CLASS &USBD_MTP

uint8_t USBD_MTP_RegisterStorage(USBD_HandleTypeDef *pdev, USBD_MTP_StorageTypeDef *fops);

#endif /* __USBD_MTP_H */
