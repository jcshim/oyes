#ifndef __USBD_MTP_IF_H__
#define __USBD_MTP_IF_H__

#include "usbd_mtp.h"

extern USBD_MTP_StorageTypeDef USBD_MTP_fops;

#endif /* __USBD_MTP_IF_H__ */
