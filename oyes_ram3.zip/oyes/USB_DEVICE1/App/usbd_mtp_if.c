#include "usbd_mtp.h"
#include "usbd_mtp_if.h"
#include "fatfs.h"
#include "string.h"
#include "ff.h"

static uint32_t storage_ids[1] = { 0x00010001 };
static char object_filename[] = "myfile.txt";

static uint16_t MTP_Init(void) {
    return 0;
}

static uint16_t MTP_DeInit(void) {
    return 0;
}

static uint16_t MTP_GetStorageIDs(uint32_t *array, uint32_t *num) {
    array[0] = storage_ids[0];
    *num = 1;
    return 0;
}

static uint16_t MTP_GetStorageInfo(uint32_t storage_id, void *storage_info_buf) {
    memset(storage_info_buf, 0, 128);
    storage_info_buf = storage_info_buf;
    return 0;
}

static uint16_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t parent, uint32_t format,
                                     uint32_t *handles_array, uint32_t *num_handles) {
    handles_array[0] = 0x00000001;
    *num_handles = 1;
    return 0;
}

static uint16_t MTP_GetObjectInfo(uint32_t object_handle, MTP_ObjectInfoTypedef *info) {
    memset(info, 0, sizeof(MTP_ObjectInfoTypedef));
    strcpy((char*)info->filename, object_filename);
    info->object_compressed_size = 0; // updated when reading
    info->format = 0x3000; // Undefined format
    info->parent_object = 0xFFFFFFFF;
    info->storage_id = storage_ids[0];
    return 0;
}

static uint16_t MTP_GetObject(uint32_t object_handle, uint8_t *buffer, uint32_t offset,
                              uint32_t length, uint32_t *actual_length) {
    FIL file;
    UINT bytes_read;

    if (f_open(&file, object_filename, FA_READ) != FR_OK)
        return 1;

    f_lseek(&file, offset);

    if (f_read(&file, buffer, length, &bytes_read) != FR_OK) {
        f_close(&file);
        return 1;
    }

    *actual_length = bytes_read;
    f_close(&file);
    return 0;
}

static uint16_t MTP_SendObjectInfo(uint32_t storage_id, uint32_t parent, MTP_ObjectInfoTypedef *info) {
    return 0;
}

static uint16_t MTP_SendObject(uint32_t object_handle, uint32_t offset, uint32_t length,
                               uint8_t *buffer, uint32_t *written) {
    return 0;
}

static uint16_t MTP_DeleteObject(uint32_t object_handle) {
    return 0;
}

USBD_MTP_StorageTypeDef USBD_MTP_fops = {
    MTP_Init,
    MTP_DeInit,
    MTP_GetStorageIDs,
    MTP_GetStorageInfo,
    MTP_GetObjectHandles,
    MTP_GetObjectInfo,
    MTP_GetObject,
    MTP_SendObjectInfo,
    MTP_SendObject,
    MTP_DeleteObject
};
