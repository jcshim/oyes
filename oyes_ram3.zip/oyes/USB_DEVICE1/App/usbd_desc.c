#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_conf.h"

#define USBD_VID     0x0483
#define USBD_PID     0x5740
#define USBD_LANGID_STRING     1033
#define USBD_MANUFACTURER_STRING     "STMicroelectronics"
#define USBD_PRODUCT_STRING_HS       "STM32 MTP Device"
#define USBD_SERIALNUMBER_STRING_HS  "00000000001A"
#define USBD_CONFIGURATION_STRING_HS "MTP Config"
#define USBD_INTERFACE_STRING_HS     "MTP Interface"

USBD_DescriptorsTypeDef MTP_Desc = {
  USBD_MTP_DeviceDescriptor,
  USBD_MTP_LangIDStrDescriptor,
  USBD_MTP_ManufacturerStrDescriptor,
  USBD_MTP_ProductStrDescriptor,
  USBD_MTP_SerialStrDescriptor,
  USBD_MTP_ConfigStrDescriptor,
  USBD_MTP_InterfaceStrDescriptor,
};

__ALIGN_BEGIN uint8_t USBD_HS_DeviceDesc[USB_LEN_DEV_DESC] __ALIGN_END = {
  0x12,                       /* bLength */
  USB_DESC_TYPE_DEVICE,       /* bDescriptorType */
  0x00, 0x02,                 /* bcdUSB 2.00 */
  0x00,                       /* bDeviceClass */
  0x00,                       /* bDeviceSubClass */
  0x00,                       /* bDeviceProtocol */
  USB_MAX_EP0_SIZE,           /* bMaxPacketSize */
  LOBYTE(USBD_VID), HIBYTE(USBD_VID), /* idVendor */
  LOBYTE(USBD_PID), HIBYTE(USBD_PID), /* idProduct */
  0x00, 0x02,                 /* bcdDevice rel. 2.00 */
  USBD_IDX_MFC_STR,           /* Index of manufacturer string */
  USBD_IDX_PRODUCT_STR,       /* Index of product string */
  USBD_IDX_SERIAL_STR,        /* Index of serial number string */
  USBD_MAX_NUM_CONFIGURATION  /* bNumConfigurations */
};

static uint8_t USBD_HS_StringSerial[USB_SIZ_STRING_SERIAL] = {
  USB_SIZ_STRING_SERIAL,
  USB_DESC_TYPE_STRING,
};

uint8_t *USBD_MTP_DeviceDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  *length = sizeof(USBD_HS_DeviceDesc);
  return USBD_HS_DeviceDesc;
}

uint8_t *USBD_MTP_LangIDStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  static uint8_t USBD_LangIDDesc[USB_LEN_LANGID_STR_DESC];
  USBD_LangIDDesc[0] = USB_LEN_LANGID_STR_DESC;
  USBD_LangIDDesc[1] = USB_DESC_TYPE_STRING;
  USBD_LangIDDesc[2] = LOBYTE(USBD_LANGID_STRING);
  USBD_LangIDDesc[3] = HIBYTE(USBD_LANGID_STRING);
  *length = sizeof(USBD_LangIDDesc);
  return USBD_LangIDDesc;
}

uint8_t *USBD_MTP_ManufacturerStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  USBD_GetString((uint8_t *)USBD_MANUFACTURER_STRING, USBD_HS_StringSerial, length);
  return USBD_HS_StringSerial;
}

uint8_t *USBD_MTP_ProductStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  USBD_GetString((uint8_t *)USBD_PRODUCT_STRING_HS, USBD_HS_StringSerial, length);
  return USBD_HS_StringSerial;
}

uint8_t *USBD_MTP_SerialStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  USBD_GetString((uint8_t *)USBD_SERIALNUMBER_STRING_HS, USBD_HS_StringSerial, length);
  return USBD_HS_StringSerial;
}

uint8_t *USBD_MTP_ConfigStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  USBD_GetString((uint8_t *)USBD_CONFIGURATION_STRING_HS, USBD_HS_StringSerial, length);
  return USBD_HS_StringSerial;
}

uint8_t *USBD_MTP_InterfaceStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length)
{
  USBD_GetString((uint8_t *)USBD_INTERFACE_STRING_HS, USBD_HS_StringSerial, length);
  return USBD_HS_StringSerial;
}
