#include "usbd_mtp.h"
#include "usbd_ctlreq.h"
#include "usbd_ioreq.h"
#include <string.h>

/* ===== Endpoint / Packet Config (FS only) ===== */
#ifndef MTP_IN_EP
#define MTP_IN_EP    0x81u   /* EP1 IN  (Bulk) */
#endif
#ifndef MTP_OUT_EP
#define MTP_OUT_EP   0x01u   /* EP1 OUT (Bulk) */
#endif
#ifndef MTP_INT_EP
#define MTP_INT_EP   0x82u   /* EP2 IN  (Interrupt for events) */
#endif

#ifndef MTP_BULK_MPS
#define MTP_BULK_MPS  64u    /* FS bulk max packet */
#endif
#ifndef MTP_INT_MPS
#define MTP_INT_MPS   16u
#endif

static USBD_MTP_ItfTypeDef *g_mtp_fops = NULL;

/* ===== Forward Declarations ===== */
static uint8_t  USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length);
static uint8_t* USBD_MTP_GetDeviceQualifierDesc(uint16_t *length);

/* ===== Class Implementation ===== */
static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  UNUSED(cfgidx);

  USBD_LL_OpenEP(pdev, MTP_IN_EP,  USBD_EP_TYPE_BULK, MTP_BULK_MPS);
  USBD_LL_OpenEP(pdev, MTP_OUT_EP, USBD_EP_TYPE_BULK, MTP_BULK_MPS);
  USBD_LL_OpenEP(pdev, MTP_INT_EP, USBD_EP_TYPE_INTR, MTP_INT_MPS);

  /* Prime OUT to avoid host timeout on first transfer */
  static uint8_t dummy_rx[64];
  USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, dummy_rx, sizeof(dummy_rx));

  return USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  UNUSED(cfgidx);
  USBD_LL_CloseEP(pdev, MTP_IN_EP);
  USBD_LL_CloseEP(pdev, MTP_OUT_EP);
  USBD_LL_CloseEP(pdev, MTP_INT_EP);
  return USBD_OK;
}

/* Minimal control handling */
static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
  uint8_t  buffer[16];

  if ((req->bmRequest & 0x60u) == 0x20u)  /* Class */
  {
    switch (req->bRequest)
    {
      case 0x67: /* GetDeviceStatus -> 0x2001 (OK) */
        buffer[0] = 0x01; buffer[1] = 0x20;
        USBD_CtlSendData(pdev, buffer, 2);
        return USBD_OK;

      case 0x65: /* GetExtendedEventData - none */
        USBD_CtlSendData(pdev, buffer, 0);
        return USBD_OK;

      case 0x64: /* CancelRequest */
      case 0x66: /* DeviceReset */
        USBD_CtlSendStatus(pdev);
        return USBD_OK;

      default:
        USBD_CtlError(pdev, req);
        return USBD_FAIL;
    }
  }

  USBD_CtlError(pdev, req);
  return USBD_FAIL;
}

/* ===== Descriptors ===== */
__ALIGN_BEGIN static uint8_t USBD_MTP_CfgDesc[] __ALIGN_END =
{
  /* Configuration */
  0x09, USB_DESC_TYPE_CONFIGURATION,
  0x27, 0x00,                    /* wTotalLength = 39 */
  0x01,                          /* bNumInterfaces */
  0x01,                          /* bConfigurationValue */
  0x00,                          /* iConfiguration */
  0x80,                          /* bmAttributes: Bus powered */
  0xFA,                          /* bMaxPower: 500mA */

  /* Interface 0: Still Image / PTP */
  0x09, USB_DESC_TYPE_INTERFACE,
  0x00,                          /* bInterfaceNumber */
  0x00,                          /* bAlternateSetting */
  0x03,                          /* bNumEndpoints */
  0x06,                          /* bInterfaceClass: Still Image */
  0x01,                          /* bInterfaceSubClass */
  0x01,                          /* bInterfaceProtocol: PTP */
  0x00,                          /* iInterface */

  /* EP1 IN  (Bulk) */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_IN_EP, 0x02,
  LOBYTE(MTP_BULK_MPS), HIBYTE(MTP_BULK_MPS),
  0x00,

  /* EP1 OUT (Bulk) */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_OUT_EP, 0x02,
  LOBYTE(MTP_BULK_MPS), HIBYTE(MTP_BULK_MPS),
  0x00,

  /* EP2 IN  (Interrupt) */
  0x07, USB_DESC_TYPE_ENDPOINT,
  MTP_INT_EP, 0x03,
  LOBYTE(MTP_INT_MPS), HIBYTE(MTP_INT_MPS),
  0x06
};

static uint8_t* USBD_MTP_GetCfgDesc(uint16_t *length)
{
  *length = sizeof(USBD_MTP_CfgDesc);
  return USBD_MTP_CfgDesc;
}

/* Qualifier (required by core API) */
__ALIGN_BEGIN static uint8_t USBD_MTP_DeviceQualifierDesc[USB_LEN_DEV_QUALIFIER_DESC] __ALIGN_END =
{
  USB_LEN_DEV_QUALIFIER_DESC,
  USB_DESC_TYPE_DEVICE_QUALIFIER,
  0x00, 0x02,
  0x06, 0x01, 0x01,
  0x40, 0x01, 0x00
};

static uint8_t* USBD_MTP_GetDeviceQualifierDesc(uint16_t *length)
{
  *length = sizeof(USBD_MTP_DeviceQualifierDesc);
  return USBD_MTP_DeviceQualifierDesc;
}

/* ===== Public API required by usb_device.c ===== */
uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops)
{
  if (fops == NULL) return USBD_FAIL;
  g_mtp_fops = fops;        // ✅ 전역 포인터에 저장
  return (uint8_t) USBD_OK;
}

/* ===== Class Callback Structure ===== */
USBD_ClassTypeDef USBD_MTP =
{
  USBD_MTP_Init,
  USBD_MTP_DeInit,
  USBD_MTP_Setup,
  NULL, /* EP0_TxSent */
  NULL, /* EP0_RxReady */
  NULL, /* DataIn */
  NULL, /* DataOut */
  NULL, /* SOF */
  NULL, /* IsoINIncomplete */
  NULL, /* IsoOUTIncomplete */
  USBD_MTP_GetCfgDesc,            /* HS Config (unused)  */
  USBD_MTP_GetCfgDesc,            /* FS Config */
  USBD_MTP_GetCfgDesc,            /* Other speed */
  USBD_MTP_GetDeviceQualifierDesc /* Qualifier */
};
