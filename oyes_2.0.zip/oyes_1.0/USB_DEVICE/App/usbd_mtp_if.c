#include "usbd_mtp_if.h"
#include "ff.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>  // for size_t
#include <ctype.h>  // tolower() 사용 시 필수

static inline void W16(uint8_t **pp, uint16_t v){ uint8_t *p=*pp; *p++=v; *p++=v>>8; *pp=p; }
static inline void W32(uint8_t **pp, uint32_t v){ uint8_t *p=*pp; *p++=v; *p++=v>>8; *p++=v>>16; *p++=v>>24; *pp=p; }
static inline void W64(uint8_t **pp, uint64_t v){ uint8_t *p=*pp; for(int i=0;i<8;i++){*p++=(uint8_t)(v>>(8*i));} *pp=p; }

/* Write MTP UTF-16LE string: [len (characters)] + UTF-16LE chars */
static void put_utf16(uint8_t **pp, const char *s)
{
    uint8_t *p = *pp;
    if (!s || !*s) { *p++ = 0; *pp = p; return; }   // 0 => 빈 문자열
    size_t n = strlen(s); if (n > 255) n = 255;
    *p++ = (uint8_t)(n + 1);                        // 문자수 + 1 (종단 포함)
    for (size_t i = 0; i < n; ++i) { *p++ = (uint8_t)s[i]; *p++ = 0x00; }
    *p++ = 0x00; *p++ = 0x00;                       // 종단 NULL (UTF-16LE)
    *pp = p;
}


static MTP_ObjectDB mtp_db;
void MTP_ScanObjects(void);

/* 문자열 끝 비교 함수 */
int ends_with(const char *str, const char *suffix)
{
    if (!str || !suffix) return 0;
    size_t len_str = strlen(str);
    size_t len_suffix = strlen(suffix);
    if (len_suffix > len_str) return 0;
    return (strcasecmp(str + len_str - len_suffix, suffix) == 0);
}

/* Scan root directory and fill mtp_db */
void MTP_ScanObjects(void)
{
    DIR dir;
    FILINFO fno;
    uint32_t handle = 1;

    mtp_db.count = 0;
    if (f_opendir(&dir, "/") != FR_OK) return;

    while (mtp_db.count < MAX_MTP_OBJECTS && f_readdir(&dir, &fno) == FR_OK && fno.fname[0]) {
        if (fno.fattrib & AM_DIR) continue; // Skip directories
        snprintf(mtp_db.objects[mtp_db.count].filepath, MAX_FILENAME_LEN, "/%s", fno.fname);
        memcpy(&mtp_db.objects[mtp_db.count].finfo, &fno, sizeof(FILINFO));
        mtp_db.objects[mtp_db.count].handle = handle++;
        mtp_db.count++;
    }

    f_closedir(&dir);
}

MTP_Object* MTP_FindObjectByHandle(uint32_t handle)
{
    for (uint32_t i = 0; i < mtp_db.count; i++) {
        if (mtp_db.objects[i].handle == handle)
            return &mtp_db.objects[i];
    }
    return NULL;
}

/* MTP Core Handlers */

static uint32_t MTP_GetDeviceInfo(uint8_t *buf, uint16_t *len)
{
    uint8_t *p = buf;

    W16(&p, 0x0100);          // StandardVersion 1.00
    W32(&p, 0x00000006);      // VendorExtensionID = 6 (MTP)
    W16(&p, 0x0064);          // MTP version 1.00 (0x0064)
    put_utf16(&p, "microsoft.com: 1.0");   // VendorExtensionDesc (★ 여기!)
    W16(&p, 0x0000);          // FunctionalMode

    // OperationsSupported (AUINT16)
    W32(&p, 9);               // 개수: 9
    W16(&p, 0x1001); // GetDeviceInfo
    W16(&p, 0x1002); // OpenSession
    W16(&p, 0x1003); // CloseSession
    W16(&p, 0x1004); // GetStorageIDs
    W16(&p, 0x1005); // GetStorageInfo
    W16(&p, 0x1007); // GetObjectHandles
    W16(&p, 0x1008); // GetObjectInfo
    W16(&p, 0x1009); // GetObject
    W16(&p, 0x1014); // GetDevicePropDesc (stub)

    // EventsSupported / DevicePropertiesSupported / CaptureFormats : 모두 0개
    W32(&p, 0);  // Events
    W32(&p, 0);  // DeviceProperties
    W32(&p, 0);  // CaptureFormats

    // Image(Object)FormatsSupported (AUINT16)
    W32(&p, 4);
    W16(&p, 0x3000); // Undefined
    W16(&p, 0x3004); // Text
    W16(&p, 0x3008); // WAV
    W16(&p, 0x3801); // JPEG

    // Strings
    put_utf16(&p, "Andong");   // Manufacturer
    put_utf16(&p, "STM32");    // Model
    put_utf16(&p, "1.0");      // Device Version
    put_utf16(&p, "SDMTP999"); // Serial Number

    *len = (uint16_t)(p - buf);
    return USBD_OK;
}



static uint32_t MTP_OpenSession(uint32_t session_id)
{
    (void)session_id;
    MTP_ScanObjects();
    if (mtp_db.count == 0) {
        snprintf(mtp_db.objects[0].filepath, MAX_FILENAME_LEN, "/hello.txt");
        strcpy(mtp_db.objects[0].finfo.fname, "hello.txt");
        mtp_db.objects[0].finfo.fsize = 20;
        mtp_db.objects[0].handle = 1;
        mtp_db.count = 1;
    }
    return USBD_OK;
}

static uint32_t MTP_CloseSession(void) { return USBD_OK; }

static uint32_t MTP_GetStorageIDs(uint8_t *buf, uint16_t *len)
{
    uint8_t *p = buf;
    W32(&p, 1);             // count = 1
    W32(&p, 0x00010001);    // storage id
    *len = (uint16_t)(p - buf);
    return USBD_OK;
}

static uint32_t MTP_GetStorageInfo(uint32_t storage_id, uint8_t *buf, uint16_t *len)
{
    (void)storage_id;
    uint8_t *p = buf;

    W16(&p, 0x0004);                       // StorageType: Removable RAM (0x0002도 가능)
    W16(&p, 0x0002);                       // FilesystemType: Generic Hierarchical
    W16(&p, 0x0000);                       // AccessCapability: Read-Write
    W64(&p, (uint64_t)128 * 1024 * 1024);  // MaxCapacity (임시 용량)
    W64(&p, (uint64_t) 64 * 1024 * 1024);  // FreeSpaceInBytes
    W32(&p, 0xFFFFFFFF);                   // FreeSpaceInObjects: unknown
    put_utf16(&p, "Andong MTP Storage");   // StorageDescription
    put_utf16(&p, "Volume1");              // VolumeIdentifier

    *len = (uint16_t)(p - buf);
    return USBD_OK;
}

static uint32_t MTP_GetObjectHandles(uint32_t storage_id, uint32_t format_code, uint32_t association, uint8_t *buf, uint16_t *len)
{
    (void)storage_id; (void)format_code; (void)association;
    uint8_t *p = buf;
    W32(&p, mtp_db.count);                  // count
    for (uint32_t i = 0; i < mtp_db.count; i++) W32(&p, mtp_db.objects[i].handle);
    *len = (uint16_t)(p - buf);
    return USBD_OK;
}

static uint32_t MTP_GetObjectInfo(uint32_t handle, uint8_t *buf, uint16_t *len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    const uint32_t storage_id = 0x00010001;  // GetStorageIDs에서 사용한 값과 동일
    const char *name = (obj->finfo.fname[0]) ? obj->finfo.fname : "unknown.txt";

    // 포맷 판별
    uint16_t format_code = 0x3000;
    const char *ext = strrchr(name, '.');
    if (ext) {
        // 대소문자 무시 ends_with 대체
        char e1 = (char)tolower((unsigned char)ext[1]);
        char e2 = (char)tolower((unsigned char)ext[2]);
        char e3 = (char)tolower((unsigned char)ext[3]);
        if ((e1=='t'&&e2=='x'&&e3=='t'))      format_code = 0x3004;
        else if ((e1=='j'&&e2=='p'&&e3=='g')) format_code = 0x3801;
        else if ((e1=='w'&&e2=='a'&&e3=='v')) format_code = 0x3008;
        else if ((e1=='m'&&e2=='p'&&e3=='3')) format_code = 0x3009;
    }

    uint8_t *p = buf;
    W32(&p, storage_id);                  // StorageID
    W16(&p, format_code);                 // ObjectFormat
    W16(&p, 0x0000);                      // ProtectionStatus
    W32(&p, (uint32_t)obj->finfo.fsize);  // ObjectCompressedSize (<=4GB 가정)

    W16(&p, 0x0000);                      // ThumbFormat
    W32(&p, 0);                           // ThumbCompressedSize
    W32(&p, 0); W32(&p, 0);               // Thumb W/H
    W32(&p, 0); W32(&p, 0);               // Image W/H (알 수 없으면 0)

    W32(&p, 0);                           // ParentObject (루트)
    W16(&p, 0x0000);                      // AssociationType
    W32(&p, 0);                           // AssociationDesc
    W32(&p, 0);                           // SequenceNumber

    put_utf16(&p, name);                  // Filename (STR)
    put_utf16(&p, NULL);                  // CaptureDate (빈)
    put_utf16(&p, NULL);                  // ModificationDate (빈)
    put_utf16(&p, NULL);                  // Keywords (빈)

    *len = (uint16_t)(p - buf);
    return USBD_OK;
}

static uint32_t MTP_GetObject(uint32_t handle, uint8_t *buf, uint32_t offset, uint32_t maxlen, uint32_t *xfer_len)
{
    MTP_Object *obj = MTP_FindObjectByHandle(handle);
    if (!obj) return USBD_FAIL;

    FIL file;
    if (f_open(&file, obj->filepath, FA_READ) != FR_OK) return USBD_FAIL;
    if (f_lseek(&file, offset) != FR_OK) { f_close(&file); return USBD_FAIL; }

    UINT br = 0;
    FRESULT res = f_read(&file, buf, maxlen, &br);
    f_close(&file);
    if (res != FR_OK) return USBD_FAIL;

    *xfer_len = br;
    return USBD_OK;
}

USBD_MTP_ItfTypeDef USBD_MTP_fops = {
    MTP_GetDeviceInfo,
    MTP_OpenSession,
    MTP_CloseSession,
    MTP_GetStorageIDs,
    MTP_GetStorageInfo,
    MTP_GetObjectHandles,
    MTP_GetObjectInfo,
    MTP_GetObject
};
