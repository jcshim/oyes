/* --------------------------------------------------------------------------
 * usbd_mtp_if.c — SafeSD 1단계: 루트에 hello.txt 하나만 보이고 읽기
 * SD카드의 /hello.txt를 실제로 읽어 Windows 탐색기에 노출합니다.
 * usbd_mtp.c 의 인터페이스 시그니처와 1:1 일치하도록 정리.
 * -------------------------------------------------------------------------- */
#include <stdint.h>
#include <string.h>
#include "usbd_core.h"   // USBD_HandleTypeDef
#include "fatfs.h"

/* ==== PTP/MTP 공통 상수 (최소) ==== */
#ifndef PTP_RC_OK
#define PTP_RC_OK            0x2001
#endif
#ifndef PTP_RC_GeneralError
#define PTP_RC_GeneralError  0x2002
#endif

/* Operations */
#ifndef PTP_OC_GetDeviceInfo
#define PTP_OC_GetDeviceInfo   0x1001
#endif
#ifndef PTP_OC_OpenSession
#define PTP_OC_OpenSession     0x1002
#endif
#ifndef PTP_OC_GetStorageIDs
#define PTP_OC_GetStorageIDs   0x1004
#endif
#ifndef PTP_OC_GetStorageInfo
#define PTP_OC_GetStorageInfo  0x1005
#endif
#ifndef PTP_OC_GetObjectHandles
#define PTP_OC_GetObjectHandles 0x1007
#endif
#ifndef PTP_OC_GetObjectInfo
#define PTP_OC_GetObjectInfo    0x1008
#endif
#ifndef PTP_OC_GetObject
#define PTP_OC_GetObject        0x1009
#endif

/* Little-Endian writers */
static inline void wr16(uint8_t *p, uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static inline void wr32(uint8_t *p, uint32_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }
static inline void wr64(uint8_t *p, uint64_t v){ for (int i=0;i<8;i++) p[i]=(uint8_t)(v>>(8*i)); }

/* PTP String (아주 단순 ASCII→UTF-16LE) */
static uint32_t wr_ptp_string(uint8_t *dst, const char *s){
  if (!s || !*s){ dst[0]=0; return 1; }
  size_t n = strlen(s); if (n>255) n=255;
  dst[0]=(uint8_t)n;
  for (size_t i=0;i<n;i++){ dst[1+2*i]=(uint8_t)s[i]; dst[2+2*i]=0; }
  return (uint32_t)(1 + 2*n);
}

/* ----- 인터페이스 타입 (usbd_mtp.c와 동일해야 함) ----- */
typedef struct
{
  uint32_t (*GetDeviceInfo)(uint8_t *buf, uint32_t max);
  int      (*OpenSession)(uint32_t id);
  int      (*CloseSession)(void);
  uint32_t (*GetStorageIDs)(uint8_t *buf, uint32_t max);
  uint32_t (*GetStorageInfo)(uint8_t *buf, uint32_t max, uint32_t storage_id);
  uint32_t (*GetObjectHandles)(uint8_t *buf, uint32_t max, uint32_t storage_id);
  uint32_t (*GetObjectInfo)(uint8_t *buf, uint32_t max, uint32_t handle);
  int      (*ObjectOpenRead)(uint32_t handle, uint32_t *size_bytes);
  int      (*ObjectReadChunk)(uint8_t *buf, uint32_t offs, uint32_t *len_inout);
  void     (*ObjectCloseRead)(void);
} USBD_MTP_ItfTypeDef;

/* usbd_mtp.c 에서 제공 */
extern uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops);

/* ===== SafeSD (hello.txt 전용) 상태 ===== */
static const char *HELLO_PATH = "/hello.txt";
static const uint32_t kStorageId = 0x00010001;

static FIL       s_fil;
static uint64_t  s_size = 0;

/* 파일 크기 얻기 */
static int hello_size(uint64_t *sz){
  FILINFO finfo;
#if FF_USE_LFN
  finfo.lfname = NULL; finfo.lfsize = 0;
#endif
  if (f_stat(HELLO_PATH, &finfo) != FR_OK) return -1;
  *sz = (uint64_t)finfo.fsize;
  return 0;
}

/* ====== DeviceInfo (최소) ====== */
static uint32_t IF_GetDeviceInfo(uint8_t *buf, uint32_t max){
  uint8_t *p = buf;
  if (max < 128) return 0;

  wr16(p, 0x0100); p+=2;            /* StandardVersion (1.00) */
  wr32(p, 6); p+=4;                 /* VendorExtensionID (MTP=6) */
  wr16(p, 0x0064); p+=2;            /* VendorExtensionVersion */
  p += wr_ptp_string(p, "MTP");     /* VendorExtensionDesc */
  wr16(p, 0x0000); p+=2;            /* FunctionalMode */

  /* OperationsSupported */
  wr32(p, 7); p+=4;
  wr16(p, PTP_OC_GetDeviceInfo);    p+=2;
  wr16(p, PTP_OC_OpenSession);      p+=2;
  wr16(p, PTP_OC_GetStorageIDs);    p+=2;
  wr16(p, PTP_OC_GetStorageInfo);   p+=2;
  wr16(p, PTP_OC_GetObjectHandles); p+=2;
  wr16(p, PTP_OC_GetObjectInfo);    p+=2;
  wr16(p, PTP_OC_GetObject);        p+=2;

  /* Events/Props/Capture/Playback — minimal empty */
  wr32(p, 0); p+=4; /* EventsSupported */
  wr32(p, 0); p+=4; /* DevicePropertiesSupported */
  wr32(p, 0); p+=4; /* CaptureFormats */
  wr32(p, 0); p+=4; /* PlaybackFormats */

  /* Manufacturer / Model / DeviceVersion / SerialNumber */
  p += wr_ptp_string(p, "SafeSD");
  p += wr_ptp_string(p, "STM32");
  p += wr_ptp_string(p, "1.0");
  p += wr_ptp_string(p, "0001");

  return (uint32_t)(p - buf);
}

static int IF_OpenSession(uint32_t sessionId){ (void)sessionId; return 0; }
static int IF_CloseSession(void){ return 0; }

/* StorageIDs: 단일 스토리지 */
static uint32_t IF_GetStorageIDs(uint8_t *buf, uint32_t max){
  if (max < 8) return 0;
  wr32(buf, 1);           /* count */
  wr32(buf+4, kStorageId);/* storage id */
  return 8;
}

/* StorageInfo (최소) */
static uint32_t IF_GetStorageInfo(uint8_t *buf, uint32_t max, uint32_t storageId){
  if (storageId != kStorageId || max < 256) return 0;
  uint8_t *p = buf;
  wr16(p, 0x0004); p+=2;  /* StorageType: Removable RAM */
  wr16(p, 0x0002); p+=2;  /* FilesystemType: Generic Hierarchical */
  wr16(p, 0x0001); p+=2;  /* AccessCapability: Read-Write */
  wr64(p, 0); p+=8;       /* MaxCapacity (unknown) */
  wr64(p, 0); p+=8;       /* FreeSpaceInBytes */
  wr32(p, 0); p+=4;       /* FreeSpaceInImages */
  p += wr_ptp_string(p, "SafeSD");
  p += wr_ptp_string(p, "SDCard");
  return (uint32_t)(p - buf);
}

/* GetObjectHandles: hello.txt가 있으면 handle=1 하나, 없으면 0개 */
static uint32_t IF_GetObjectHandles(uint8_t *buf, uint32_t max, uint32_t storageId){
  if (storageId != kStorageId || max < 4) return 0;
  if (hello_size(&s_size) != 0){
    wr32(buf, 0);       /* count=0 */
    return 4;
  }
  if (max < 8) return 0;
  wr32(buf, 1);         /* count */
  wr32(buf+4, 1);       /* handle=1 */
  return 8;
}

/* ObjectInfo: handle=1 → hello.txt */
static uint32_t IF_GetObjectInfo(uint8_t *buf, uint32_t max, uint32_t handle){
  if (handle != 1 || max < 256) return 0;
  if (hello_size(&s_size)!=0) return 0;

  uint8_t *p = buf;
  wr32(p, kStorageId); p+=4;      /* StorageID */
  wr16(p, 0x3000); p+=2;          /* ObjectFormat: Undefined/Text 등 단순 */
  wr16(p, 0); p+=2;               /* ProtectionStatus */
  wr32(p, (s_size>0xFFFFFFFFULL)?0xFFFFFFFFu:(uint32_t)s_size); p+=4; /* size */
  memset(p, 0, 2+4+4+4+4+4+4); p += (2+4+4+4+4+4+4);          /* Thumb/Img fields */
  wr32(p, 0); p+=4;               /* ParentObject (root) */
  wr16(p, 0); p+=2;               /* AssociationType */
  wr32(p, 0); p+=4;               /* AssociationDesc */
  wr32(p, 0); p+=4;               /* SequenceNumber */
  p += wr_ptp_string(p, "hello.txt");
  p += wr_ptp_string(p, "");
  p += wr_ptp_string(p, "");
  p += wr_ptp_string(p, "");
  return (uint32_t)(p - buf);
}

/* Read stream */
static int IF_ObjectOpenRead(uint32_t handle, uint32_t *size_bytes){
  if (handle != 1) return -1;
  if (hello_size(&s_size)!=0) return -1;
  if (f_open(&s_fil, HELLO_PATH, FA_READ)!=FR_OK) return -1;
  *size_bytes = (s_size > 0xFFFFFFFFULL) ? 0xFFFFFFFFu : (uint32_t)s_size;
  return 0;
}

static int IF_ObjectReadChunk(uint8_t *dst, uint32_t offs, uint32_t *len_inout){
  UINT br = 0;
  if (f_lseek(&s_fil, offs) != FR_OK) return -1;
  if (f_read(&s_fil, dst, *len_inout, &br)!=FR_OK) return -1;
  *len_inout = br;
  return 0;
}

static void IF_ObjectCloseRead(void){
  f_close(&s_fil);
}

/* ===== 인터페이스 테이블 내보내기 ===== */
USBD_MTP_ItfTypeDef USBD_MTP_fops = {
  .GetDeviceInfo    = IF_GetDeviceInfo,
  .OpenSession      = IF_OpenSession,
  .CloseSession     = IF_CloseSession,
  .GetStorageIDs    = IF_GetStorageIDs,
  .GetStorageInfo   = IF_GetStorageInfo,
  .GetObjectHandles = IF_GetObjectHandles,
  .GetObjectInfo    = IF_GetObjectInfo,
  .ObjectOpenRead   = IF_ObjectOpenRead,
  .ObjectReadChunk  = IF_ObjectReadChunk,
  .ObjectCloseRead  = IF_ObjectCloseRead,
};

/* CubeMX 일부 템플릿 호환용(사용 안 해도 무방) */
uint8_t USBD_MTP_If_Register(USBD_HandleTypeDef *pdev)
{
  return USBD_MTP_RegisterInterface(pdev, &USBD_MTP_fops);
}
