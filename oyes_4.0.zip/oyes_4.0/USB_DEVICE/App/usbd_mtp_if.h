#ifndef __USBD_MTP_IF_H__
#define __USBD_MTP_IF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_mtp.h"
#include "ff.h"         // FatFS
#include <stdint.h>
#include <string.h>

#define MAX_MTP_OBJECTS    100      // 최대 100개 파일까지 지원
#define MAX_FILENAME_LEN   64       // 전체 경로 포함 최대 파일 경로 길이

/* MTP 객체 정보 구조체: 핸들, 경로, 파일 정보 */
typedef struct {
    uint32_t handle;                   // MTP 오브젝트 핸들
    char filepath[MAX_FILENAME_LEN];  // SD 카드 상의 전체 파일 경로 (예: "/hello.txt")
    FILINFO finfo;                    // FatFS 파일 정보
} MTP_Object;

/* MTP 오브젝트 데이터베이스 구조체 */
typedef struct {
    uint32_t count;                   // 등록된 파일 개수
    MTP_Object objects[MAX_MTP_OBJECTS];
} MTP_ObjectDB;

/* Exported interface */
extern USBD_MTP_ItfTypeDef USBD_MTP_fops;

/* 파일 시스템 연동 함수 */
void MTP_ScanObjects(void);                   // SD 루트 디렉토리 재스캔
MTP_Object* MTP_FindObjectByHandle(uint32_t handle);  // 핸들로 객체 검색

#ifdef __cplusplus
}
#endif

#endif /* __USBD_MTP_IF_H__ */
