/**
  ******************************************************************************
  * @file    usbd_mtp.c
  * @brief   Minimal MTP/PTP class that delegates datasets and object data
  *          to user fops (usbd_mtp_if.c). Streams /hello.txt from SD.
  ******************************************************************************
  */

#include "usbd_core.h"
#include "usbd_ctlreq.h"
#include <string.h>

/* ---------- Config (Endpoint numbers must match descriptors) ---------- */
#ifndef MTP_IN_EP
#define MTP_IN_EP     0x81  /* Bulk IN  */
#endif
#ifndef MTP_OUT_EP
#define MTP_OUT_EP    0x01  /* Bulk OUT */
#endif
#ifndef MTP_EVT_EP
#define MTP_EVT_EP    0x83  /* Interrupt IN (events) — EP3 to match TxFIFO in usbd_conf.c */
#endif

#define USB_MTP_CONFIG_DESC_SIZ   (9+9+7+7+7)
#define MTP_DATA_MAX_PACKET_SIZE  64U
#define MTP_EVT_PACKET_SIZE       16U

/* PTP/MTP basic constants */
#define PTP_CONTAINER_UNDEFINED   0
#define PTP_CONTAINER_COMMAND     1
#define PTP_CONTAINER_DATA        2
#define PTP_CONTAINER_RESPONSE    3
#define PTP_CONTAINER_EVENT       4

#define PTP_RC_OK                 0x2001
#define PTP_RC_GENERAL_ERROR      0x2002
#define PTP_RC_OPERATION_NOT_SUPPORTED 0x2005

#define PTP_OC_GetDeviceInfo      0x1001
#define PTP_OC_OpenSession        0x1002
#define PTP_OC_CloseSession       0x1003
#define PTP_OC_GetStorageIDs      0x1004
#define PTP_OC_GetStorageInfo     0x1005
#define PTP_OC_GetNumObjects      0x1006
#define PTP_OC_GetObjectHandles   0x1007
#define PTP_OC_GetObjectInfo      0x1008
#define PTP_OC_GetObject          0x1009

/* Optional user interface (delegation to if.c) */
typedef struct
{
  uint32_t (*GetDeviceInfo)(uint8_t *buf, uint32_t max);
  int      (*OpenSession)(uint32_t id);
  int      (*CloseSession)(void);
  uint32_t (*GetStorageIDs)(uint8_t *buf, uint32_t max);
  uint32_t (*GetStorageInfo)(uint8_t *buf, uint32_t max, uint32_t storage_id);
  uint32_t (*GetObjectHandles)(uint8_t *buf, uint32_t max, uint32_t storage_id);
  uint32_t (*GetObjectInfo)(uint8_t *buf, uint32_t max, uint32_t handle);
  int      (*ObjectOpenRead)(uint32_t handle, uint32_t *size_bytes);
  int      (*ObjectReadChunk)(uint8_t *buf, uint32_t offs, uint32_t *len_inout);
  void     (*ObjectCloseRead)(void);
} USBD_MTP_ItfTypeDef;

static USBD_MTP_ItfTypeDef *MTP_fops = NULL;

uint8_t USBD_MTP_RegisterInterface(USBD_HandleTypeDef *pdev, USBD_MTP_ItfTypeDef *fops)
{
  (void)pdev;
  MTP_fops = fops;
  return (uint8_t)USBD_OK;
}

/* Object formats */
#define PTP_OFC_Text              0x3004

/* Internal state */
typedef struct {
  uint32_t session_open;
  uint32_t transaction_id;
  uint8_t  rx_buf[512];
  uint8_t  tx_buf[512];
  uint32_t rx_len;
  uint32_t tx_len;

  /* streaming state for GetObject */
  uint8_t  streaming;
  uint32_t obj_size;
  uint32_t obj_offs;
  uint32_t obj_tid;
} MTP_HandleTypeDef;

static MTP_HandleTypeDef hmtp;

/* ---- helpers ---- */
static inline uint16_t rd16(const uint8_t *p){ return (uint16_t)(p[0] | (p[1]<<8)); }
static inline uint32_t rd32(const uint8_t *p){ return (uint32_t)(p[0] | (p[1]<<8) | (p[2]<<16) | (p[3]<<24)); }
static inline void wr16(uint8_t *p, uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static inline void wr32(uint8_t *p, uint32_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }

/* ------------------------- Descriptors ------------------------------- */
__ALIGN_BEGIN static uint8_t USBD_MTP_FS_CfgDesc[] __ALIGN_END =
{
  /* Configuration Descriptor */
  0x09,                         /* bLength */
  USB_DESC_TYPE_CONFIGURATION,  /* bDescriptorType */
  (uint8_t)(USB_MTP_CONFIG_DESC_SIZ & 0xFF),
  (uint8_t)(USB_MTP_CONFIG_DESC_SIZ >> 8), /* wTotalLength */
  0x01,                         /* bNumInterfaces */
  0x01,                         /* bConfigurationValue */
  0x00,                         /* iConfiguration */
  0x80,                         /* bmAttributes: Bus powered */
  0x32,                         /* bMaxPower: 100 mA */

  /* Interface Descriptor */
  0x09,                         /* bLength */
  USB_DESC_TYPE_INTERFACE,      /* bDescriptorType */
  0x00,                         /* bInterfaceNumber */
  0x00,                         /* bAlternateSetting */
  0x03,                         /* bNumEndpoints = 3 */
  0x06,                         /* bInterfaceClass = Still Image */
  0x01,                         /* bInterfaceSubClass */
  0x01,                         /* bInterfaceProtocol = PTP */
  0x00,                         /* iInterface */

  /* EP 0x81 Bulk IN */
  0x07,                         /* bLength */
  USB_DESC_TYPE_ENDPOINT,       /* bDescriptorType */
  MTP_IN_EP,                    /* bEndpointAddress (IN) */
  0x02,                         /* bmAttributes = Bulk */
  LOBYTE(MTP_DATA_MAX_PACKET_SIZE), HIBYTE(MTP_DATA_MAX_PACKET_SIZE), /* wMaxPacketSize */
  0x00,                         /* bInterval */

  /* EP 0x01 Bulk OUT */
  0x07,                         /* bLength */
  USB_DESC_TYPE_ENDPOINT,       /* bDescriptorType */
  MTP_OUT_EP,                   /* bEndpointAddress (OUT) */
  0x02,                         /* bmAttributes = Bulk */
  LOBYTE(MTP_DATA_MAX_PACKET_SIZE), HIBYTE(MTP_DATA_MAX_PACKET_SIZE), /* wMaxPacketSize */
  0x00,                         /* bInterval */

  /* EP 0x83 Interrupt IN (MTP Event) */
  0x07,                         /* bLength */
  USB_DESC_TYPE_ENDPOINT,       /* bDescriptorType */
  MTP_EVT_EP,                   /* bEndpointAddress (IN) */
  0x03,                         /* bmAttributes = Interrupt */
  LOBYTE(MTP_EVT_PACKET_SIZE), HIBYTE(MTP_EVT_PACKET_SIZE),           /* wMaxPacketSize */
  0x06,                         /* bInterval (ms) */
};

/* 10-byte device qualifier (required by core) */
__ALIGN_BEGIN static uint8_t USBD_MTP_DeviceQualifierDesc[] __ALIGN_END =
{
  0x0A,                         /* bLength */
  USB_DESC_TYPE_DEVICE_QUALIFIER,
  0x00, 0x02,                   /* bcdUSB 2.00 */
  0x00,                         /* bDeviceClass (in FS we use interface class) */
  0x00,                         /* bDeviceSubClass */
  0x00,                         /* bDeviceProtocol */
  MTP_DATA_MAX_PACKET_SIZE,     /* bMaxPacketSize0 (EP0) -> usually 64 */
  0x01,                         /* bNumConfigurations */
  0x00
};

/* --------------------- USBD class forward decls ---------------------- */
static uint8_t  USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t  USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req);
static uint8_t  USBD_MTP_EP0_TxReady(USBD_HandleTypeDef *pdev);
static uint8_t  USBD_MTP_EP0_RxReady(USBD_HandleTypeDef *pdev);
static uint8_t  USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t  USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t  USBD_MTP_SOF(USBD_HandleTypeDef *pdev);
static uint8_t  USBD_MTP_IsoINIncomplete(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t  USBD_MTP_IsoOUTIncomplete(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t* USBD_MTP_GetFSConfigDescriptor(uint16_t *length);
static uint8_t* USBD_MTP_GetHSConfigDescriptor(uint16_t *length);
static uint8_t* USBD_MTP_GetOtherSpeedCfgDesc(uint16_t *length);
static uint8_t* USBD_MTP_GetDeviceQualifierDescriptor(uint16_t *length);

/* Class structure (Cube H7 style) */
USBD_ClassTypeDef USBD_MTP =
{
  USBD_MTP_Init,
  USBD_MTP_DeInit,
  USBD_MTP_Setup,
  USBD_MTP_EP0_TxReady,
  USBD_MTP_EP0_RxReady,
  USBD_MTP_DataIn,
  USBD_MTP_DataOut,
  USBD_MTP_SOF,
  USBD_MTP_IsoINIncomplete,
  USBD_MTP_IsoOUTIncomplete,
  USBD_MTP_GetHSConfigDescriptor,
  USBD_MTP_GetFSConfigDescriptor,
  USBD_MTP_GetOtherSpeedCfgDesc,
  USBD_MTP_GetDeviceQualifierDescriptor
};

/* -------------------- Small helpers to send -------------------------- */

static void MTP_SendResponse(USBD_HandleTypeDef *pdev, uint16_t code, uint32_t tid)
{
  uint8_t *b = hmtp.tx_buf;
  wr32(b+0, 12);                 /* length */
  wr16(b+4, PTP_CONTAINER_RESPONSE);
  wr16(b+6, code);
  wr32(b+8, tid);
  hmtp.tx_len = 12U;
  USBD_LL_Transmit(pdev, MTP_IN_EP, b, hmtp.tx_len);
}

static void MTP_SendDataAndResponse(USBD_HandleTypeDef *pdev, uint16_t op, uint32_t tid,
                                    const uint8_t *payload, uint32_t paylen)
{
  uint32_t total = 12U + paylen;
  uint8_t *b = hmtp.tx_buf;
  wr32(b+0, total);
  wr16(b+4, PTP_CONTAINER_DATA);
  wr16(b+6, op);
  wr32(b+8, tid);
  if (paylen && payload) {
    uint32_t n = (paylen > (uint32_t)(sizeof(hmtp.tx_buf)-12U)) ? (uint32_t)(sizeof(hmtp.tx_buf)-12U) : paylen;
    for (uint32_t i=0;i<n;i++) b[12+i]=payload[i];
    hmtp.tx_len = 12U + n;
  } else {
    hmtp.tx_len = 12U;
  }
  USBD_LL_Transmit(pdev, MTP_IN_EP, b, hmtp.tx_len);
  hmtp.transaction_id = tid; /* DataIn()에서 Response(OK) */
}

/* === Streaming for GetObject === */
static void MTP_StreamStart(USBD_HandleTypeDef *pdev, uint32_t tid, uint32_t total_size)
{
  hmtp.streaming = 1U;
  hmtp.obj_size  = total_size;
  hmtp.obj_offs  = 0U;
  hmtp.obj_tid   = tid;

  /* header + first chunk */
  uint8_t *b = hmtp.tx_buf;
  uint32_t room = (uint32_t)sizeof(hmtp.tx_buf) - 12U;
  uint32_t n = room;
  if (n > total_size) n = total_size;

  /* Read first chunk via fops */
  if (MTP_fops && MTP_fops->ObjectReadChunk){
    uint32_t want = n;
    if (MTP_fops->ObjectReadChunk(b+12, 0U, &want) == 0){
      n = want;
    } else {
      /* read error */
      hmtp.streaming = 0U;
      MTP_fops->ObjectCloseRead ? MTP_fops->ObjectCloseRead() : (void)0;
      MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid);
      return;
    }
  } else {
    hmtp.streaming = 0U;
    MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid);
    return;
  }

  /* send data container header + first payload */
  wr32(b+0, 12U + total_size);
  wr16(b+4, PTP_CONTAINER_DATA);
  wr16(b+6, PTP_OC_GetObject);
  wr32(b+8, tid);
  USBD_LL_Transmit(pdev, MTP_IN_EP, b, 12U + n);
  hmtp.obj_offs = n;
}

/* ----------------------- Class callbacks ----------------------------- */

static uint8_t USBD_MTP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  (void)cfgidx;
  memset(&hmtp, 0, sizeof(hmtp));

  USBD_LL_OpenEP(pdev, MTP_IN_EP,  USBD_EP_TYPE_BULK, MTP_DATA_MAX_PACKET_SIZE);
  USBD_LL_OpenEP(pdev, MTP_OUT_EP, USBD_EP_TYPE_BULK, MTP_DATA_MAX_PACKET_SIZE);
  USBD_LL_OpenEP(pdev, MTP_EVT_EP, USBD_EP_TYPE_INTR, MTP_EVT_PACKET_SIZE);

  pdev->ep_in[MTP_IN_EP & 0xFU].is_used   = 1U;
  pdev->ep_out[MTP_OUT_EP & 0xFU].is_used = 1U;
  pdev->ep_in[MTP_EVT_EP & 0xFU].is_used  = 1U;

  /* prepare OUT reception */
  USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, hmtp.rx_buf, sizeof(hmtp.rx_buf));
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
  (void)cfgidx;
  USBD_LL_CloseEP(pdev, MTP_IN_EP);
  USBD_LL_CloseEP(pdev, MTP_OUT_EP);
  USBD_LL_CloseEP(pdev, MTP_EVT_EP);

  pdev->ep_in[MTP_IN_EP & 0xFU].is_used   = 0U;
  pdev->ep_out[MTP_OUT_EP & 0xFU].is_used = 0U;
  pdev->ep_in[MTP_EVT_EP & 0xFU].is_used  = 0U;

  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_Setup(USBD_HandleTypeDef *pdev, USBD_SetupReqTypedef *req)
{
  if ((req->bmRequest & USB_REQ_TYPE_MASK) == USB_REQ_TYPE_CLASS ||
      (req->bmRequest & USB_REQ_TYPE_MASK) == USB_REQ_TYPE_VENDOR)
  {
    USBD_CtlError(pdev, req);
    return (uint8_t)USBD_FAIL;
  }
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_EP0_TxReady(USBD_HandleTypeDef *pdev)
{ (void)pdev; return (uint8_t)USBD_OK; }

static uint8_t USBD_MTP_EP0_RxReady(USBD_HandleTypeDef *pdev)
{ (void)pdev; return (uint8_t)USBD_OK; }

static uint8_t USBD_MTP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
  (void)epnum;

  /* Continue streaming object data (if any) */
  if (hmtp.streaming)
  {
    if (hmtp.obj_offs < hmtp.obj_size)
    {
      uint32_t remain = hmtp.obj_size - hmtp.obj_offs;
      uint32_t n = (remain > (uint32_t)sizeof(hmtp.tx_buf)) ? (uint32_t)sizeof(hmtp.tx_buf) : remain;

      if (MTP_fops && MTP_fops->ObjectReadChunk){
        uint32_t want = n;
        if (MTP_fops->ObjectReadChunk(hmtp.tx_buf, hmtp.obj_offs, &want) == 0 && want > 0U){
          USBD_LL_Transmit(pdev, MTP_IN_EP, hmtp.tx_buf, want);
          hmtp.obj_offs += want;
          return (uint8_t)USBD_OK;
        }
      }

      /* read error → abort */
      if (MTP_fops && MTP_fops->ObjectCloseRead) MTP_fops->ObjectCloseRead();
      hmtp.streaming = 0U;
      MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, hmtp.obj_tid);
      return (uint8_t)USBD_OK;
    }

    /* finished */
    if (MTP_fops && MTP_fops->ObjectCloseRead) MTP_fops->ObjectCloseRead();
    hmtp.streaming = 0U;
    MTP_SendResponse(pdev, PTP_RC_OK, hmtp.obj_tid);
    return (uint8_t)USBD_OK;
  }

  /* If previous op used MTP_SendDataAndResponse(), send OK response now */
  if (hmtp.transaction_id != 0U)
  {
    MTP_SendResponse(pdev, PTP_RC_OK, hmtp.transaction_id);
    hmtp.transaction_id = 0U;
  }
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
  (void)epnum;

  uint8_t *b = hmtp.rx_buf;
  uint32_t xfer = USBD_LL_GetRxDataSize(pdev, MTP_OUT_EP);
  if (xfer < 12U) { goto rearm; }

  uint32_t len = rd32(b+0);
  uint16_t type = rd16(b+4);
  uint16_t code = rd16(b+6);
  uint32_t tid  = rd32(b+8);

  if (type != PTP_CONTAINER_COMMAND || len != xfer) { goto rearm; }

  switch (code)
  {
    case PTP_OC_GetDeviceInfo:
    {
      uint32_t n = 0U;
      if (MTP_fops && MTP_fops->GetDeviceInfo) n = MTP_fops->GetDeviceInfo(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U);
      if (n == 0U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      MTP_SendDataAndResponse(pdev, PTP_OC_GetDeviceInfo, tid, hmtp.tx_buf+12, n);
    } break;

    case PTP_OC_OpenSession:
      hmtp.session_open = 1U;
      if (MTP_fops && MTP_fops->OpenSession) (void)MTP_fops->OpenSession(rd32(b+12));
      MTP_SendResponse(pdev, PTP_RC_OK, tid);
      break;

    case PTP_OC_CloseSession:
      hmtp.session_open = 0U;
      if (MTP_fops && MTP_fops->CloseSession) (void)MTP_fops->CloseSession();
      MTP_SendResponse(pdev, PTP_RC_OK, tid);
      break;

    case PTP_OC_GetStorageIDs:
    {
      uint32_t n = (MTP_fops && MTP_fops->GetStorageIDs) ? MTP_fops->GetStorageIDs(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U) : 0U;
      if (n == 0U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      MTP_SendDataAndResponse(pdev, PTP_OC_GetStorageIDs, tid, hmtp.tx_buf+12, n);
    } break;

    case PTP_OC_GetStorageInfo:
    {
      uint32_t sid = rd32(b+12);
      uint32_t n = (MTP_fops && MTP_fops->GetStorageInfo) ? MTP_fops->GetStorageInfo(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U, sid) : 0U;
      if (n == 0U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      MTP_SendDataAndResponse(pdev, PTP_OC_GetStorageInfo, tid, hmtp.tx_buf+12, n);
    } break;

    case PTP_OC_GetNumObjects:
      /* if.c가 핸들을 0개로 줄 수 있으므로 여기서는 1개를 보장하지 않음 */
      /* 간단히 if.c의 GetObjectHandles 길이를 보고 개수를 재사용 */
    {
      uint32_t n = (MTP_fops && MTP_fops->GetObjectHandles) ? MTP_fops->GetObjectHandles(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U, rd32(b+12)) : 0U;
      if (n < 4U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      /* 첫 4바이트는 count */
      uint32_t count = rd32(hmtp.tx_buf+12);
      wr32(hmtp.tx_buf+12, count);
      MTP_SendDataAndResponse(pdev, PTP_OC_GetNumObjects, tid, hmtp.tx_buf+12, 4U);
    } break;

    case PTP_OC_GetObjectHandles:
    {
      uint32_t n = (MTP_fops && MTP_fops->GetObjectHandles) ? MTP_fops->GetObjectHandles(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U, rd32(b+12)) : 0U;
      if (n == 0U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      MTP_SendDataAndResponse(pdev, PTP_OC_GetObjectHandles, tid, hmtp.tx_buf+12, n);
    } break;

    case PTP_OC_GetObjectInfo:
    {
      uint32_t handle = rd32(b+12);
      uint32_t n = (MTP_fops && MTP_fops->GetObjectInfo) ? MTP_fops->GetObjectInfo(hmtp.tx_buf+12, sizeof(hmtp.tx_buf)-12U, handle) : 0U;
      if (n == 0U) { MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid); break; }
      MTP_SendDataAndResponse(pdev, PTP_OC_GetObjectInfo, tid, hmtp.tx_buf+12, n);
    } break;

    case PTP_OC_GetObject:
    {
      uint32_t handle = rd32(b+12);
      uint32_t size = 0U;
      if (MTP_fops && MTP_fops->ObjectOpenRead && MTP_fops->ObjectReadChunk && MTP_fops->ObjectCloseRead)
      {
        if (MTP_fops->ObjectOpenRead(handle, &size) == 0U && size > 0U){
          MTP_StreamStart(pdev, tid, size);
          break;
        }
      }
      /* fallback (should not reach here in SafeSD) */
      MTP_SendResponse(pdev, PTP_RC_GENERAL_ERROR, tid);
    } break;

    default:
      MTP_SendResponse(pdev, PTP_RC_OPERATION_NOT_SUPPORTED, tid);
      break;
  }

rearm:
  USBD_LL_PrepareReceive(pdev, MTP_OUT_EP, hmtp.rx_buf, sizeof(hmtp.rx_buf));
  return (uint8_t)USBD_OK;
}

static uint8_t USBD_MTP_SOF(USBD_HandleTypeDef *pdev)
{ (void)pdev; return (uint8_t)USBD_OK; }

static uint8_t USBD_MTP_IsoINIncomplete(USBD_HandleTypeDef *pdev, uint8_t epnum)
{ (void)pdev; (void)epnum; return (uint8_t)USBD_OK; }

static uint8_t USBD_MTP_IsoOUTIncomplete(USBD_HandleTypeDef *pdev, uint8_t epnum)
{ (void)pdev; (void)epnum; return (uint8_t)USBD_OK; }

static uint8_t* USBD_MTP_GetFSConfigDescriptor(uint16_t *length)
{ *length = (uint16_t)sizeof(USBD_MTP_FS_CfgDesc); return USBD_MTP_FS_CfgDesc; }

static uint8_t* USBD_MTP_GetHSConfigDescriptor(uint16_t *length)
{ return USBD_MTP_GetFSConfigDescriptor(length); }

static uint8_t* USBD_MTP_GetOtherSpeedCfgDesc(uint16_t *length)
{ return USBD_MTP_GetFSConfigDescriptor(length); }

static uint8_t* USBD_MTP_GetDeviceQualifierDescriptor(uint16_t *length)
{ *length = (uint16_t)sizeof(USBD_MTP_DeviceQualifierDesc); return USBD_MTP_DeviceQualifierDesc; }
